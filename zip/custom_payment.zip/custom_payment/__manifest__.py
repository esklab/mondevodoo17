{
    'name': 'Custom Paiement',
    'version': '1.0',
    'description': 'Custom Paiement',
    'summary': 'Custom Paiement',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'account',
        'sale_management',
        'account_accountant',
    ],
    "data": [],
    'auto_install': False,
    'application': True,
}