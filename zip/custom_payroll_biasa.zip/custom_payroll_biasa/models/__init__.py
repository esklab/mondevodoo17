from . import hr_contrat_inherit
from . import hr_salary
from . import hr_contrat_prime