{
    'name': 'Custom Active Add',
    'version': '1.0',
    'description': 'Custom Active Add',
    'summary': 'Custom Active Add',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'sale_management',
        'purchase',
        'account',
    ],
    "data": [],
    'auto_install': False,
    'application': True,
}