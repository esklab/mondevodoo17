{
    'name': 'Custom Facture',
    'version': '1.0',
    'description': 'Custom Facture',
    'summary': 'Custom Facture',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'account',
        'sale_management',
    ],
    "data": [],
    'auto_install': False,
    'application': True,
}