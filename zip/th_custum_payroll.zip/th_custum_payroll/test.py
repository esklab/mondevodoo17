import datetime

date = datetime.datetime.today().year
print(date)

date = datetime.datetime.today().year

print(date)