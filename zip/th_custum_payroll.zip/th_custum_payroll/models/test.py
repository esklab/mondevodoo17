a = 60508

# b = str(a)[-3] + str(a)[-2] + str(a)[-1]
# c = float(b)
# d = a-c

d = (int(a/1000)) *1000
print(d)

