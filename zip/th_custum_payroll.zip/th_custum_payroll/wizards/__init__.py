# -*- coding: utf-8 -*-

from . import payroll_pdf_report
from . import livre_annuel_pdf
# from . import dnr_excel_report
from . import payroll_report_wiz
