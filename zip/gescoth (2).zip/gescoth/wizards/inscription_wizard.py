# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import datetime

class GescothInscriptionWizard(models.TransientModel):

    _name = 'gescoth.inscription.wizard'
    _description = 'Inscription'

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Annee Scolaire',
        required=True,
        default=lambda self: self.env['gescoth.anneescolaire'].browse(
            int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
        ),
        )
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        required=True,
    )

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
        required=True,
    )
    date_inscription = fields.Date(string="Date d'inscription")


    @api.model
    def default_get(self, fields):
        res = super(GescothInscriptionWizard, self).default_get(fields)
        res['date_inscription'] = datetime.date.today()
        if self.env.context.get('active_id'):
            res['eleve_id'] = self.env.context.get('active_id')
        return res

    def inscription_eleve(self):
        for rec in self:
            annee = (self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
            if not annee:
                raise ValidationError(_("Veuillez configurer l'Année Académique"))
            vals = {
                'annee_scolaire_id': int(annee) ,
                'classe_id': rec.classe_id.id,
                'eleve_id': rec.eleve_id.id,
                'date_inscription': rec.date_inscription
            }
            inscrit  = self.env['gescoth.eleve.inscription'].search([
                ('eleve_id','=', rec.eleve_id.id),
                ('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))),
            ], limit=1)
            if inscrit:
                inscrit.classe_id = rec.classe_id.id
            else:
                self.env['gescoth.eleve.inscription'].create(vals)



