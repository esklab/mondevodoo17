# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError

class GescothFicheNote(models.TransientModel):
	_name = 'gescoth.note.eleve'
	_description = "Impression de la fiche de note"

	classe_id = fields.Many2one('gescoth.classe', string='classe', required=True,)
	unite_id = fields.Many2one(
	    'unite.enseignement',
	    string='Unité d\'enseignement',
	)
	prof_id = fields.Many2one(
	    'gescoth.personnel',
	    string='Enseignant',
	)

	def imprimer_fiche_note(self):
		data = {}
		liste_des_eleves = []
		eleves = self.env['gescoth.eleve'].search([('classe','=',self.classe_id.id)])
		if len(eleves) == 0:
			raise ValidationError(_('Pas encore d\'inscrit dans cette classe'))
		for el in eleves:
			vals ={
			'matricule':el.name,
			'nom_eleve' : el.nom_eleve,
            'sexe' : el.sexe,
            'classe': self.classe_id.name,
            'matiere' : self.unite_id.name,
            'prof': self.prof_id.name,
			}
			liste_des_eleves.append(vals)

		# raise UserError(_(liste_des_eleves))

		data['liste_des_eleves']= liste_des_eleves
		data['entete'] = self.env['ir.config_parameter'].sudo().get_param('gescoth.entete')
		return self.env.ref('gescoth.fiche_note_report_view').report_action(self, data=data)