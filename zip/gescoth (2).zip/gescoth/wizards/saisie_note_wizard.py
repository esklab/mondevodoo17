# -*- coding: utf-8 -*-
from odoo import _, api, fields, models, tools
from odoo.exceptions import UserError, ValidationError

class GescothSaiseNoteWizard(models.TransientModel):

    _name = 'gescoth.saise.note.wizard'
    _description = 'Saise de note'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='classe',
        required=True, 
        )
    annee_scolaire = fields.Many2one(
		'gescoth.anneescolaire', 
		required=True, 
		string="Année Académique",
		default=lambda self: self.env['gescoth.anneescolaire'].browse(
            int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
        ),
	)
    saison = fields.Selection([
		('S1','Semestre 1'),
		('S2','Semestre 2'),
		('s3','Semestre 3')
		], 
		required=True,
    )
    credit_id = fields.Many2one('unite.credit',required=True, string="Unité d'enseignement",)

    note_ids = fields.Many2many('universite.note')

    @api.onchange('classe_id','annee_scolaire','saison','credit_id')
    def _get_notes(self):
        notes = self.env['universite.note'].search([
            ('classe_id','=', self.classe_id.id),
            ('annee_scolaire_id','=', self.annee_scolaire.id),
            ('saison','=', self.saison),
            ('credit_id','=',self.credit_id.id),
        ])
        self.note_ids = notes.ids

    @api.onchange('classe_id')
    def _get_self_coef_ids(self):
        for rec in self:
            return {'domain':{'credit_id':[('classe_id','=',self.classe_id.id)]}}

    def confirmer_saisie(self):        
        saisie = self.env['ir.config_parameter'].sudo().get_param('gescoth.saisie_note')
        if saisie:
            matiere = self.env['unite.credit'].search([
                ('id','=', self.credit_id.id),
                ('professeur_id.user_id','=', self.env.uid)
            ])
            if not matiere :
                raise UserError(_('Vous n\'êtes pas autorisé à saisir ces notes ! Veuillez contactez votre administrateur'))
            
        return{
            'name':('Notes de ' + self.classe_id.name + ' - ' + self.annee_scolaire.name + ' - ' + self.saison + ' - ' + self.credit_id.unite_id.name),
            'domain':[
                ('classe_id','=', self.classe_id.id),
                ('annee_scolaire_id','=', self.annee_scolaire.id),
                ('saison','=', self.saison),
                ('credit_id','=',self.credit_id.id),
            ],
            'res_model':'universite.note',
            'view_id':False,
            'view_mode':'tree,form',
            'type':'ir.actions.act_window',
        }