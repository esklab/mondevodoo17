from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError

class FichePresence(models.TransientModel):

    _name = 'fiche.presence'
    _description = 'Fiche de présence'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe', required=True
    )
    
    saison = fields.Selection([('S1','1er semestre'),('S2','Second semestre')], required=True)
   
    type_examen_ = fields.Selection(string='Type d\'examen', selection=[
		('CC', 'Controle continue (CC)'),
		('TP', 'Travaux partiques (TP)'),
		('TPE', 'Travaux partique individuel (TPE)'),
		('SN', 'Session normal'),
		('RT', 'Rattrapage')
	], required=True)

    credit_id = fields.Many2one(
        'unite.credit',
        string='Unité d\'enseignement',
        )

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique',
        required=True,
        default=lambda self: self.env['gescoth.anneescolaire'].browse(
            int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
        ),
    )


    def imprimer_fichie_presnece(self):
        data = {}

        note_ids = self.env['universite.note'].search([
            ('classe_id','=', self.classe_id.id),
            ('credit_id','=', self.credit_id.id),
        ])

        liste_des_etudiants =[]
        for note_id in note_ids:
            if self.type_examen_ != 'RT':
                if note_id.get_validation().validation == 'EC' or not  note_id.get_validation():
                    vals = {
                        'matricule': note_id.eleve_id.name,
                        'nom_prenom': note_id.eleve_id.display_name,
                        'montant_paye': note_id.eleve_id.paiement_total,
                    }
                else:
                    vals = {
                        'matricule': note_id.eleve_id.name,
                        'nom_prenom': note_id.eleve_id.display_name,
                        'montant_paye': note_id.eleve_id.paiement_total,
                    }
                liste_des_etudiants.append(vals)
            else:
                if note_id.get_validation().validation == 'CA':
                    vals = {
                        'matricule': note_id.eleve_id.name,
                        'nom_prenom': note_id.eleve_id.display_name,
                        'montant_paye': note_id.eleve_id.paiement_total,
                    }
                    liste_des_etudiants.append(vals)

        data['liste_des_etudiants'] = liste_des_etudiants
        data['classe'] = self.classe_id.name,
        data['unite_enseignement'] = self.credit_id.unite_id.name
        data['annee_scolaire'] = self.annee_scolaire_id.name
        data['niveau'] = self.classe_id.niveau_id.name
        data['type_examen_'] = dict(self._fields['type_examen_'].selection).get(self.type_examen_)
        data['saison'] = '1er semestre' if self.saison == 'S1' else 'Second semestre'
        return self.env.ref('gescoth.liste_presence_report_view').report_action(self, data=data)

