from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError

class UniteGenereNote(models.TransientModel):

    _name = 'unite.genere.note'
    _description = 'Générer les notes'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe', required=True
    )

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire', 
        required=True, 
        string="Année Académique",
        default=lambda self: self.env['gescoth.anneescolaire'].browse(
            int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
        ),
    )

    saison = fields.Selection([
        ('S1','Semestre 1'),
        ('S2','Semestre 2'),
        ], string='Saison',
        required=True,
    )

 
    def generer_note_unite_a_saisir(self):
        eleve_ids = self.env['gescoth.eleve.inscription'].search([
            ('classe_id','=', self.classe_id.id),
            ('annee_scolaire_id','=', self.annee_scolaire_id.id)
        ])
        # eleve_ids = self.env['gescoth.eleve'].search([('classe','=',self.classe_id.id)])
        if len(eleve_ids) == 0:
            raise ValidationError(_("Pas encore d'étudiants inscrits dans cette classe : " + self.classe_id.name))

        for eleve in eleve_ids:
            for credit in self.classe_id.credit_ids:
                if credit.saison == self.saison:
                    vals = {
                    'eleve_id':eleve.eleve_id.id,
                    'classe_id':self.classe_id.id,
                    'credit_id':credit.id,
                    'saison':credit.saison,
                    'module_id':credit.module_id.id,
                    'annee_scolaire_id':self.annee_scolaire_id.id,
                    }
                    note = self.env['universite.note'].search([
                        ('eleve_id','=', vals['eleve_id']),
                        ('classe_id','=', vals['classe_id']),
                        ('credit_id','=', vals['credit_id']),
                        ('saison','=', vals['saison']),
                        ('annee_scolaire_id','=', vals['annee_scolaire_id']),
                    ], limit=1)
                    
                    if not note:
                        self.env['universite.note'].create(vals)
        
        return{
			'name':('Notes'),
			'domain':[('classe_id','=', self.classe_id.id),('annee_scolaire_id','=', self.annee_scolaire_id.id)],
			'res_model':'universite.note',
			'view_id':False,
			'view_mode':'tree,form',
			'type':'ir.actions.act_window',
		}