from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError

class ListeParNiveau(models.TransientModel):

    _name = 'liste.par.niveau'
    _description = 'Liste des étudiants par niveau'

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire', 
        required=True, 
        string="Année Académique",
        default=lambda self: self.env['gescoth.anneescolaire'].browse(
            int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
        ),
    )
    niveau_id = fields.Many2one(
        'gescoth.niveau',
        string='Niveau',
    )

    def imprimer_liste_eleve(self):
        data = {}
        liste_des_eleves = []
        eleves_inscrits = self.env['gescoth.eleve.inscription'].search([('annee_scolaire_id','=', self.annee_scolaire_id.id)])
        eleves_inscrits = eleves_inscrits.sorted(lambda line: line.eleve_id.nom_eleve)

        for inscrit in eleves_inscrits:
            if inscrit.eleve_id.niveau_id.id == self.niveau_id.id:
                vals ={
                    'matricule':inscrit.eleve_id.name,
                    'nom_eleve' : inscrit.eleve_id.nom_eleve,
                    'photo' : inscrit.eleve_id.photo,
                    'date_naissance' : inscrit.eleve_id.date_naissance,
                    'lieu_naissance' : inscrit.eleve_id.lieu_naissance,
                    'sexe' : inscrit.eleve_id.sexe,
                    'nationalite' : inscrit.eleve_id.nationalite,
                    'classe' : inscrit.eleve_id.classe.name,
                    'filiere': inscrit.eleve_id.classe.filiere.name,
                    'statut' : inscrit.eleve_id.statut,
                    'Apt_sport' : inscrit.eleve_id.Apt_sport,
                }
                liste_des_eleves.append(vals)
        data['liste_des_eleves']= liste_des_eleves
        data['entete'] = self.env['ir.config_parameter'].sudo().get_param('gescoth.entete')
        data['niveau'] = self.niveau_id.name
        return self.env.ref('gescoth.liste_eleve_report_view').report_action(self, data=data)

