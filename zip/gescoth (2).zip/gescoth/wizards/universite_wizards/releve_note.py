from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError

class ReleveNote(models.TransientModel):

    _name = 'releve.note'
    _description = 'Releve de note'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe', required=True
    )
    eleve_id = fields.Many2one(
		'gescoth.eleve',
		string='Etudiant',
    )
    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique',
        required=True,
        default=lambda self: self.env['gescoth.anneescolaire'].browse(
            int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
        ),
    )

    def get_grade(self, note):
        grade = 'f'
        moyenne_sur_4 = 0
        if note >= 0 and note < 6:
            grade = 'F'
            moyenne_sur_4 = 0
        elif note >= 6 and note < 8:
            grade = 'E'
            moyenne_sur_4 = 1
        elif note >= 8 and note < 9:
            grade = 'D'
            moyenne_sur_4 = 1.3
        elif note >= 9 and note < 10:
            grade = 'C-'
            moyenne_sur_4 = 1.7
        elif note >= 10 and note < 11:
            grade = 'C'
            moyenne_sur_4 = 2
        elif note >= 11 and note < 12:
            grade = 'C+'
            moyenne_sur_4 = 2.3
        elif note >= 12 and note < 13:
            grade = 'B-'
            moyenne_sur_4 = 2.7
        elif note >= 13 and note < 14:
            grade = 'B'
            moyenne_sur_4 = 3
        elif note >= 14 and note < 16:
            grade = 'B+'
            moyenne_sur_4 = 3.3
        elif note >= 16 and note < 18:
            grade = 'A'
            moyenne_sur_4 = 3.7
        elif note >= 18:
            grade = 'A+'
            moyenne_sur_4 = 4

        return {
            'grade': grade,
            'moyenne_sur_4':moyenne_sur_4
        }

    def imprimer_releve_note(self):
        data = {}
        liste_note = []
        etudiant_ids = self.env['gescoth.eleve.inscription'].search([
            ('classe_id','=', self.classe_id.id),
            ('annee_scolaire_id','=', self.annee_scolaire_id.id)
        ])

        if len(etudiant_ids) <= 0:
            raise ValidationError(_("Pas encore d'étudiants dans cette classe !"))
        
        for el in etudiant_ids:
            eleve = {
                'id':el.eleve_id.id,
                'nom_eleve': el.eleve_id.nom_eleve,
                'matricule': el.eleve_id.name,
                'date_naissance':el.eleve_id.date_naissance,
                'lieu_naissance':el.eleve_id.lieu_naissance,
                'classe':el.eleve_id.classe.name,
                'filiere': el.eleve_id.classe.filiere.name,
                'niveau':el.eleve_id.niveau_id.name,
                'sexe':'Masculin' if el.eleve_id.sexe == 'masculin' else 'Féminin',
                'Apt_sport':el.eleve_id.Apt_sport,
                'statut':el.eleve_id.statut,
                'saison':'Premiere trimestre',
            }
            notes = self.env['unite.validation'].search([
                ('eleve_id','=', el.eleve_id.id),
                ('classe_id','=',self.classe_id.id),
                ('annee_scolaire_id','=',self.annee_scolaire_id.id),
            ])
            if not notes:
                raise UserError(_('Veullez générer les notes !'))

            note_eleve = []
            total_credit = 0
            total_credit_capital = 0
            total_note = 0
            pourcentage_credit = 0
            for note in notes:
                total_credit += note.credit_id.credit
                total_note += (note.moyenne * note.credit)
                total_credit_capital += note.credit
                vals_note = {
                    'code': note.credit_id.unite_id.code,
                    'matiere': note.credit_id.unite_id.name,
                    'moyenne':note.moyenne,
                    '':"{0:.2f}".format(note.moyenne),
                    'moyenne_sur_cent':"{0:.2f}".format(note.moyenne_sur_cent),
                    'credit': note.credit_id.credit,
                    'point': "{0:.2f}".format(note.point),
                    'appreciation':note.appreciation,
                    'grade':notemoyenne_sur_20.grade,
                    'state':note.state,                    
                }
                note_eleve.append(vals_note)
            if self.classe_id.get_total_credit():
                pourcentage_credit = (total_credit_capital / total_credit)*100

            resultat = self.env['gescoth.unite.resultat'].search([
                ('eleve_id','=', el.id),
                ('annee_scolaire_id','=', self.annee_scolaire_id.id),
                
            ], limit=1)          
            eleve['decision'] = resultat.decision
            eleve['notes'] = note_eleve
            eleve['total_credit_capital'] = total_credit_capital
            eleve['pourcentage_credit'] = "{0:.0f}".format(pourcentage_credit)
            eleve['total_credit'] = total_credit
            eleve['total_note'] = "{0:.2f}".format(total_note)
            eleve['grade'] = self.get_grade((total_note / total_credit_capital))['grade']
            eleve['moyenne_pondere'] = total_note / total_credit_capital
            liste_note.append(eleve)
                        

        liste_definitive = []
        list_unique = []

        for eleve in liste_note:
            if eleve['id'] == self.eleve_id.id:
                list_unique.append(eleve)
        if len(list_unique) == 1:
            liste_definitive = list_unique
        else :
            liste_definitive = liste_note

        data['note_des_eleve'] = liste_definitive
        data['annee_scolaire'] = self.annee_scolaire_id.name
        # data['saison'] = self.saison.upper()
        data['entete'] = self.env['ir.config_parameter'].sudo().get_param('gescoth.entete')
        
        return self.env.ref('gescoth.releve_note_report_view').report_action(self, data=data)
