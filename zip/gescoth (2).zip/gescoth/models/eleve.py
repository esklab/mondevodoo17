# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


# from twilio.rest import Client

# classe étudiant pour inscrire les Etudiants de l'établissement
class GescothEtudiant(models.Model):
	_name = 'gescoth.eleve'
	_inherit = ['mail.thread','mail.activity.mixin']
	_description = 'Etudiant'
	_rec_name = 'nom_eleve'
	_order = 'name'

	name = fields.Char(string="N° Matricule", equired=True, copy=False, default='Matricule')
	matricule_fn_public = fields.Char(string='Matricule à la fonction publique')
	nom_eleve = fields.Char(string="Nom et prénom(s)", store=True, copy=True,)
	nom_famille = fields.Char(string="Nom de famille", required=True,)
	prenom = fields.Char(string="Prénom(s)")
	photo = fields.Binary(string="Photo de l'étudiant")
	date_naissance = fields.Date(string="Date de naissance",track_visibility='always', default='')
	lieu_naissance = fields.Char(string="Lieu de naissance", default='')
	sexe = fields.Selection([('masculin','Masculin'),('feminin','Féminin')], string="Sexe", default='')
	nationalite = fields.Many2one('res.country', string="Nationalité", default= lambda self: int( self.env.user.company_id.country_id.id))
	telephone = fields.Char(string="Téléphone", track_visibility='onchange', default='')
	email =  fields.Char(string="E-mail", track_visibility='always')
	adresse= fields.Text(string="Adresse complète", default='')
	region = fields.Char(string='Région')
	arrondissement = fields.Char(string='Arrondissement')
	departement = fields.Char(string='Département')
	classe = fields.Many2one('gescoth.classe', string="Classe", default='')
	date_inscription = fields.Date(string="Date d'inscription",default=fields.Date.today())

	entete = fields.Binary(string="Entete", compute="_get_entete")
	
	est_fonctionnaire = fields.Boolean(
		string='Est un fonctionnaire',
	)
	
	niveau_id = fields.Many2one(
	    'gescoth.niveau',
	    string="Niveau d'étude",
	)
	annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année académique en cours', compute="_calcul_annee_scolaire"
	)
	numero_cni = fields.Char(string="N° de carte d'indentité nationale")
	statut = fields.Selection([('N','Nouveau'),('D','Doublant'),('T','Triplant'),('Q','Quatriplant')], string='Statut', default='N')
	Apt_sport = fields.Boolean(string="Apte pour le sport", default=True)
	info_medicaux_ids = fields.One2many('gescoth.info.medicaux', 'eleve_id', string="Information médicales")
	active = fields.Boolean(string="Active", default=True)
	scolaire_anterieur_ids = fields.One2many(
        'gescoth.scolarite.anterieur', 'eleve_id', string="Scolarité antérieur")

	liste_des_absences_total = fields.Integer(
	    string='Total',
	    compute="_liste_des_absences_total",
	)
	liste_des_retards_total = fields.Integer(
	    string='Total',
	    compute="_liste_des_retards_total",
	)
	liste_des_punitions_total = fields.Integer(
	    string='Total',
	    compute="_liste_des_punitions_total",
	)
	liste_des_parents_total = fields.Integer(
	    string='Total',
	    compute="_liste_des_parents_total",
	)
	paiement_total = fields.Float(
	    string='Total',
	    compute="_paiement_total",
	)

	total_reste_a_payer = fields.Float(string="Reste à payer", compute="_calcule_rest_a_payer")

	conduite_ids = fields.One2many(
	    'gescoth.conduite',
	    'eleve_id',
	    string='Conduite',
	)
	date_arrive = fields.Date(string="Date d'arrivée dans l'établissement")
	derinier_etablissement = fields.Char(string="Dernier établissement férquenté")
	taille = fields.Float(string='Taille de l\'étudiant')
	groupe_sangin = fields.Selection(string='Group sangin', selection=[
		('1', 'A+'),
		('2', 'A-'),
		('3', 'B+'),
		('4', 'B-'),
		('5', 'O+'),
		('6', 'O-'),
		('7', 'AB+'),
		('8', 'AB-'),
		])
	absences =  fields.Float(string="Absence", compute="_calcul_absence")
	retard =  fields.Float(string="Retard", compute="_calcul_absence")
	punition =  fields.Float(string="Punition", compute="_calcul_absence")
	parent_ids = fields.One2many(
	    'gescoth.parent.eleve',
	    'eleve_id',
	    string='Parents/Tuteurs',
	)
	responsable_id = fields.Many2one(
	    'res.users',
	    string='Responsable',
	    default=lambda self: self.env.user.id,
	    readonly=True,
	)

	unite_libre_ids = fields.One2many('unite.credit', 'eleve_id')
	
	ue_non_valide_ids = fields.Many2many('unite.validation', compute="_get_note", string='Unités non validées',)
	
	company_id = fields.Many2one(
        'res.company',
        string='Société',
        copy=True, store=True, index=True, 
        ondelete='restrict',
        default=lambda self: self.env['res.company']._company_default_get('gescoth').id
	
	)
	def _get_note(self):
		for rec in self:
			rec.ue_non_valide_ids = self.env['unite.validation'].search([
				('eleve_id','=', rec.id),
				('credit','=',0)
			]).ids

	def suspendre_etudiant(self):
		for rec in self:
			inscripton = self.env['gescoth.eleve.inscription'].search([
				('eleve_id','=', rec.id),
				('active','=', True),
				('annee_scolaire_id','=', rec.annee_scolaire_id.id)
			], limit=1).activer_inscription(False)
			rec.active = False
		
	def activer_etudiant(self):
		for rec in self:
			inscripton = self.env['gescoth.eleve.inscription'].search([
				('eleve_id','=', rec.id),
				('active','=', False),
				('annee_scolaire_id','=', rec.annee_scolaire_id.id)
			], limit=1).activer_inscription(True)
			rec.active = True

	def _get_entete(self):
		for rec in self:
			rec.entete = self.env['ir.config_parameter'].sudo().get_param('gescoth.entete')

	def _calcul_annee_scolaire(self):
		for rec in self:
			rec.annee_scolaire_id = int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
   

	def _calcule_rest_a_payer(self):
		for rec in self:
			paiements = self.env['gescoth.paiement.eleve'].search([('eleve_id','=',rec.id),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))])
			current_country_id = self.env.user.company_id.country_id.id
			# raise UserError(_(str(self.nationalite.id) + " - " + str(current_country_id)))
			subvention = 0
			if current_country_id == rec.nationalite.id:
				total_paye = 0
				for p in paiements:
					total_paye += p.montant
				if rec.est_fonctionnaire:
					rec.total_reste_a_payer = rec.niveau_id.frais_formation_fonctionnaire - total_paye
				else:
					rec.total_reste_a_payer = rec.niveau_id.frais_formation_nat - total_paye

			else:
				total_paye = 0
				for p in paiements:
					total_paye += p.montant				
				rec.total_reste_a_payer = rec.niveau_id.frais_formation_inter - total_paye

	@api.onchange('classe')
	def onchange_classe(self):
		for rec in self:
			rec.niveau_id = rec.classe.niveau_id.id
	
	@api.depends('nom_famille','prenom')
	@api.onchange('nom_famille','prenom')
	def onchange_nom_famille(self):
		for rec in self:
			if rec.nom_famille:
				rec.nom_eleve = rec.nom_famille
			if rec.nom_famille and rec.prenom:
				rec.nom_eleve = rec.nom_famille + " " + rec.prenom

	def envoyer_carte_eleve(self):
		template_id= self.env.ref('gescoth.eleve_email_template').id
		template = self.env['mail.template'].browse(template_id)
		return template.send_mail(self.id, force_send=True)


	def liste_des_absences(self):
		return{
			'name':('Conduites'),
			'domain':[('eleve_id','=', self.id),('type_conduite','=','absence'),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))],
			'res_model':'gescoth.conduite',
			'view_id':False,
			'view_mode':'tree,form',
			'type':'ir.actions.act_window',
		}
	def _liste_des_absences_total(self):
		for rec in self:
			conduite = self.env['gescoth.conduite'].search([('eleve_id','=', rec.id),('type_conduite','=','absence'),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))])
			total = 0
			for c in conduite:
				total += c.nombre_heure
			rec.liste_des_absences_total = total


	def liste_des_retards(self):
		return{
			'name':('Retards'),
			'domain':[('eleve_id','=', self.id),('type_conduite','=','retard'),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))],
			'res_model':'gescoth.conduite',
			'view_id':False,
			'view_mode':'tree,form',
			'type':'ir.actions.act_window',
		}
	def _liste_des_retards_total(self):
		for rec in self:
			conduite = self.env['gescoth.conduite'].search([('eleve_id','=', rec.id),('type_conduite','=','retard'),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))])
			total = 0
			for c in conduite:
				total += c.nombre_heure
			rec.liste_des_retards_total = total

	def liste_des_punitions(self):
		return{
			'name':('Punition'),
			'domain':[('eleve_id','=', self.id),('type_conduite','=','punition'),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))],
			'res_model':'gescoth.conduite',
			'view_id':False,
			'view_mode':'tree,form',
			'type':'ir.actions.act_window',
		}
	def _liste_des_punitions_total(self):
		for rec in self:
			conduite = self.env['gescoth.conduite'].search([('eleve_id','=', rec.id),('type_conduite','=','punition'),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))])
			total = 0
			for c in conduite:
				total += c.nombre_heure
			rec.liste_des_punitions_total = total

	def liste_des_parents(self):
		return{
			'name':('Parents'),
			'domain':[('eleve_id','=', self.id)],
			'res_model':'gescoth.parent.eleve',
			'view_id':False,
			'view_mode':'tree,form',
			'type':'ir.actions.act_window',
		}

	def _paiement_total(self):
		for rec in self:
			list_paiement_total = self.env['gescoth.paiement.eleve'].search([('eleve_id','=', rec.id),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))])
			montant = 0
			for p in list_paiement_total:
				montant += p.montant
			rec.paiement_total = montant


	def liste_des_paiements(self):
		return{
			'name':('Paiements'),
			'domain':[('eleve_id','=', self.id),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))],
			'res_model':'gescoth.paiement.eleve',
			'view_id':False,
			'view_mode':'tree,form',
			'type':'ir.actions.act_window',
		}
	def _liste_des_parents_total(self):
		for rec in self:
			rec.liste_des_parents_total = len(self.env['gescoth.parent.eleve'].search([('eleve_id','=', rec.id)]))

	def _calcul_absence(self):
		for rec in self:
			conduite = self.env['gescoth.conduite'].search([('eleve_id', '=', rec.id), ('annee_scolaire_id', '=', int(
				self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))])
			n=0
			n2=0
			n3=0
			for ab in conduite:
				if ab.type_conduite == 'absence':
					n += ab.nombre_heure
				if ab.type_conduite == 'retard':
					n2 += ab.nombre_heure
				if ab.type_conduite == 'punition':
					n3 += ab.nombre_heure

			rec.absences = n
			rec.retard = n2
			rec.punition = n3

	def afficher_conduite(self, anneescolaire, saison):
		conduite = self.env['gescoth.conduite'].search([
			('eleve_id','=',self.id),
			('annee_scolaire_id','=', anneescolaire),
			('saison','=', saison),
		])
		absences=0
		retard=0
		punition=0
		for ab in conduite:
			if ab.type_conduite == 'absence':
				absences += ab.nombre_heure
			if ab.type_conduite == 'retard':
				retard += ab.nombre_heure
			if ab.type_conduite == 'punition':
				punition += ab.nombre_heure

		return {
			'absences':absences,
			'retard':retard,
			'punition':punition,
		}

	@api.model
	def create(self, vals):
		n = self.env['gescoth.eleve'].search([])
		# if len(n)>=20:
		# 	raise ValidationError(_('Vous ne vous pouvez pas enregistrer plus de ' + n + ' Etudiants pour cette version'))
		if vals.get('name', 'Matricule') == 'Matricule':
			vals['name'] = self.env['ir.sequence'].next_by_code(
				'gescoth.eleve') or 'Matricule'
		result = super(GescothEtudiant, self).create(vals)
		annee = (self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
		if not annee:
			raise ValidationError(_("Veuillez configurer l'Année Académique"))
		vals = {
			'annee_scolaire_id': int(annee) ,
			'classe_id': result.classe.id,
			'eleve_id': result.id,
			'sexe': vals['sexe'],
			'date_inscription': fields.Date.today()
		}
		inscrit  = self.env['gescoth.eleve.inscription'].search([
			('eleve_id','=', result.id),
			('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))),
		], limit=1)
		if inscrit:
			inscrit.classe_id = rec.classe_id,
		else:
			self.env['gescoth.eleve.inscription'].create(vals)
		return result

	def write(self, values):
		res = super().write(values)
		annee = (self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))
		if not annee:
			raise ValidationError(_("Veuillez configurer l'Année Académique"))
				
		vals = {
			'annee_scolaire_id': int(annee) ,
			'classe_id': self.classe,
			'eleve_id': self.id,
			'date_inscription': fields.Date.today()
		}
		inscrit  = self.env['gescoth.eleve.inscription'].search([
			('eleve_id','=', self.id),
			('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id'))),
		], limit=1)
		if inscrit:
			inscrit.classe_id = self.classe.id,
			inscrit.sexe = self.sexe
		else:
			self.env['gescoth.eleve.inscription'].create(vals)
		return res


class GescothParentEtudiant(models.Model):
	_name = 'gescoth.parent.eleve'
	_description = "Parent d'étudiant"

	name = fields.Char(
		string='Nom et prénom(s)',
		required=True
		)
	email = fields.Char(
		string='E-mail',
		)
	telephone = fields.Char(
		string='Téléphone',
		required=True,
		)
	Adresse = fields.Text(
		string='Adresse',
		)
	type_parent = fields.Selection([
		('mere', 'Mère'),
		('pere', 'Père'),
		('tante', 'Tante'),
		('frère', 'Frère'),
		('oncle', 'Oncle'),
		('tuteur', 'Tuteur'),
	], string="Lien parentale")
	eleve_id = fields.Many2many(
		'gescoth.eleve',
		string='Etudiant',
		required=True,
	)
	photo = fields.Binary(string="Photo")


class GescothConduite(models.Model):
    _name = 'gescoth.conduite'
    _description = 'Conduite'
    _rec_name="eleve_id"

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
        required=True,
    )
    date_conduite = fields.Date(
        string='Date',
        required=True,
        default =fields.Date.today(),
    )
    type_conduite = fields.Selection([
    	('absence','Absence'),
    	('retard','Retard'),
    	('punition','Punition')
    ], string="Type",
    required=True,)

    saison = fields.Selection([
    	('S1','Semestre 1'),
    	('S2','Semestre 2'),
    	('s3','Semestre 3'),
    ], required=True)

    nombre_heure = fields.Float(
        string="Nombre d'heure",
        required=True,
    )
    motif = fields.Text(
        string='Motif',
    )
    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique',
        required=True,
        default=lambda self: self.env['gescoth.anneescolaire'].search([('id', '=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))], limit=1)
    )

class gescothScolariteAnterieur(models.Model):
    
    _name = 'gescoth.scolarite.anterieur'
    _description = 'Scolarité antérieur'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
    )
    annescolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique',
		required=True
		
    )
    etablisement = fields.Char(string="Etablissement",required=True)
    country_id = fields.Many2one(
		'res.country',
		string='Pays',required=True
		)
    villde = fields.Char(string="Ville",required=True)
    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
    )

class GescothInfoMedicaux(models.Model):
    
	_name = 'gescoth.info.medicaux'
	_description = 'Informations médicales'

	nom_medecin = fields.Char(string="Nom du médécin", 
	required=True
	)
	telephone_medecin = fields.Char(string="Téléphone")
	date_visite = fields.Date(string="Dernière visite médicale",required=True)
	oberserations = fields.Text(string="Obervations médicales")
	email = fields.Char("Email")
	eleve_id = fields.Many2one(
		'gescoth.eleve',
		string='Etudiant',
		)


class GescothInscription(models.Model):

	_name = 'gescoth.inscription'
	_description = 'Inscription'

	classe_id = fields.Many2one(
		'gescoth.classe',
		string='classe',
		)

	annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique',
        required=True,
    	default=lambda self: self.env['gescoth.anneescolaire'].browse(int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))
    )
