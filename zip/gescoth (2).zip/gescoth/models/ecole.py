# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

# classe pour gérer les matières


class GescothMatiere(models.Model):
	_name = 'gescoth.matiere'
	_description = 'Gestion des matière'
	_sql_constraints = [
	('name_uniq', 'unique (name)', _('Cette matière existe déjà !')),
	]

	name = fields.Char(string="Nom de la matière", required=True)
	nom_abrege = fields.Char(string="Nom abrégé")
	user_abrege = fields.Boolean(string="Utiliser le nom abrégé")
	type_matiere = fields.Selection([
		('theorie','Théorique'),
		('sport','Stportive'),		
	],
	string="Type de matière",
	default="theorie",
	required=True,)



#classe pour gerer les classes
class GescothClasse(models.Model):
	_name = 'gescoth.classe'
	_description = 'Gestion des classes'
	_sql_constraints = [
	('name_uniq', 'unique (name)', _('Cette classe existe déjà !')),
	]

	name = fields.Char(string="Nom de la classe", required=True, index=True)
	description = fields.Char(string='Description')
	filiere = fields.Many2one('gescoth.filiere', required=True)
	professeur = fields.Many2one('gescoth.personnel', string="Enseignant titulaire")
	coeficient_ids = fields.One2many('gescoth.coeficient', 'name', string="Coeficient de matières")
	credit_ids = fields.One2many('unite.credit', 'classe_id', string="Crédit")
	eleve_ids =  fields.One2many('gescoth.eleve', 'classe', string="Liste des Etudiants")
	moyenne_admission = fields.Float(string='Moyenne(MGP) d\'admission', default=10)
	credit_admission = fields.Integer(string='Crédit d\'admission')
	classe_sup_id = fields.Many2one(
		'gescoth.classe',
		string='Classe Supérieur',
		)

	liste_des_eleves_total = fields.Integer(
	    string='Total',
	    compute="_liste_des_eleves_total"
	)
	liste_des_filles_total = fields.Integer(string="Total des filles", compute="_calucle_liste_des_filles")
	
	liste_des_garcons_total = fields.Integer(string="Total des garcons", compute="_calucle_liste_des_garcons")

	niveau_id = fields.Many2one('gescoth.niveau', required=True)

	color = fields.Char(
        string="Color",
        help="Choose your color",
        size=7
    )
	total_matiere = fields.Integer(string="Total matière", compute="_compute_total_matiere")

	total_paiement_nat = fields.Float(string="Total paiement", compute="_compute_total_paiement_nat")
	total_paiement_inter = fields.Float(string="Total paiement", compute="_compute_total_paiement_inter")
	total_paiement_fonctionnaire =  fields.Float(string="Total paiement", compute="_total_paiement_fonctionnaire")

	def get_total_credit(self):
		for rec in self:
			total = 0
			for credit in rec.credit_ids:
				total += credit.credit
			return total

	def _compute_total_paiement_nat(self):
		for rec in self:
			rec.total_paiement_nat = rec.niveau_id.frais_formation_nat

	def _compute_total_paiement_inter(self):
		for rec in self:
			rec.total_paiement_inter = rec.niveau_id.frais_formation_inter

	def _total_paiement_fonctionnaire(self):
		for rec in self:
			rec.total_paiement_fonctionnaire = rec.niveau_id.frais_formation_fonctionnaire

	def _compute_total_matiere(self):
		for rec in self:
			total = 0
			for coeficient_id in rec.credit_ids:
				total += 1
			rec.total_matiere = total

	def _calucle_liste_des_filles(self):
		for rec in self:
			rec.liste_des_filles_total = len(self.env['gescoth.eleve'].search([('classe','=', rec.id),('sexe','=','feminin')]))
	
	def _calucle_liste_des_garcons(self):
		for rec in self:
			rec.liste_des_garcons_total = len(self.env['gescoth.eleve'].search([('classe','=', rec.id),('sexe','=','masculin')]))

	
	def liste_des_professeurs(self):
		return{
			'name':('Professeurs'),
			'domain':[('id','=', self.professeur.id)],
			'res_model':'gescoth.personnel',
			'view_id':False,
			'view_mode':'tree,form,kanban',
			'type':'ir.actions.act_window',
		}

	def nouvelle_eleve(self):
		return{
			'name':('Etudiants'),
			'domain':[('classe','=', self.id)],
			'res_model':'gescoth.eleve',
			'view_id':False,
			'view_mode':'form',
			'type':'ir.actions.act_window',
		}
	
	def liste_des_unite_enseignements(self):
		return{
			'name':('Unité d\'enseignement'),
			'domain':[('classe_id','=', self.id)],
			'res_model':'unite.credit',
			'view_id':False,
			'view_mode':'tree,form,kanban',
			'type':'ir.actions.act_window',
		}

	def nouvelle_classe(self):
		return{
			'name':('Classe'),
			'res_model':'gescoth.classe',
			'domain':[('classe','=', self.id)],
			'view_id':False,
			'view_mode':'form',
			'type':'ir.actions.act_window',
		}

	def liste_des_garcons(self):
		return{
			'name':('Etudiants garçons'),
			'domain':[('classe','=', self.id),('sexe','=','masculin')],
			'res_model':'gescoth.eleve',
			'view_id':False,
			'view_mode':'tree,form,kanban',
			'type':'ir.actions.act_window',
		}

	def liste_des_filles(self):
		return{
			'name':('Etudiants filles'),
			'domain':[('classe','=', self.id),('sexe','=','feminin')],
			'res_model':'gescoth.eleve',
			'view_id':False,
			'view_mode':'tree,form,kanban',
			'type':'ir.actions.act_window',
		}



	def liste_des_eleves(self):
		return{
			'name':('Etudiants de ' + self.name),
			'domain':[('classe','=', self.id)],
			'res_model':'gescoth.eleve',
			'view_id':False,
			'view_mode':'tree,form,kanban',
			'type':'ir.actions.act_window',
		}

	def _liste_des_eleves_total(self):
		for rec in self:
			rec.liste_des_eleves_total = len(self.env['gescoth.eleve'].search([('classe','=', rec.id)]))


class GescothFiliere(models.Model):
	_name = 'gescoth.filiere'
	_description = 'Gestion des filiere'
	_sql_constraints = [
	('name_uniq', 'unique (name)', _('Cette filiere existe déjà !')),
	]

	name = fields.Char(string="Nom de filiere", required=True)
	specialite = fields.Char(string="Spécialité")
	classe_ids = fields.One2many('gescoth.classe', 'filiere', string="Liste des classe")

class gescothHoraire(models.Model):
    _name = 'gescoth.horaire'
    _description = 'Horaire'

    name = fields.Char(
    	string='Horaire',
    	required=True,
    )
    heure_debut = fields.Float(
        string='Heure de début',
        required=True,
    )
    heure_fin = fields.Float(
        string='Heure de fin',
        required=True,
    )

class gescothEmploiTemps(models.Model):
	_name = 'gescoth.emploi.temps'
	_description = 'Emploi du temps'
	_rec_name = 'classe_id'

	classe_id = fields.Many2one(
		'gescoth.classe',
		string='Classe',
		)
	numero_amphi = fields.Char(string='Salle de cours')
	saison = fields.Selection([('S1','Semestre 1'),('S2','Semestre 2'),('s3','Semestre 3')], required=True)
	annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année Académique',
    	default=lambda self: self.env['gescoth.anneescolaire'].browse(int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))
	)

	emploi_line_ids = fields.One2many('gescoth.emploi.temps.line', 'emploi_id')

class gescothEmploiTempsLine(models.Model):
	_name = 'gescoth.emploi.temps.line'
	_description = 'Emploi du temps'

	date = fields.Date(string='Date')

	titre_du_cours = fields.Char(string='Titre du cours')

	emploi_id = fields.Many2one(
		'gescoth.emploi.temps',
		string='Emploi du temps',
		required=True,
	)
	professeur_ids = fields.Many2many('gescoth.personnel', string="Intervenants")
	
	horaire_id = fields.Many2one(
		'gescoth.horaire',
		string='Horaire',
	)
	unite_id = fields.Many2one(
		'unite.enseignement',
		string='Unité d\'enseignement',
		)
	heure_debut = fields.Float(
		string='Heure de début',
		# compute="_calculer_heure",
	)
	heure_fin = fields.Float(
		string='Heure de fin',
		# compute="_calculer_heure",
	)
	type_de_cours = fields.Selection([
		('cm', 'CM'),
		('tpe','TPE'),
		('tdtp','TD/TP'),
		('tp','TP')
	])

	@api.onchange('horaire_id')
	def _onchange_horaire_id(self):
		for rec in self:
			rec.heure_fin = rec.horaire_id.heure_fin
			rec.heure_debut = rec.horaire_id.heure_debut

class GescothNiveau(models.Model):
	_name = 'gescoth.niveau'
	_description = 'Nieau'

	name = fields.Char(
		string='Description',
		required=True,
	)
	numer_semestre = fields.Selection([
		('1', '1'),
		('2', '2'),
		('3', '3'),
		('4', '4'),
		('5', '5'),
		('6', '6'),
		('7', '7'),
		('8', '8'),
		('9', '9'),
		('10', '10'),
		('11', '11'),
		('12', '12'),
	])
	note = fields.Char(string="Note")
	frais_inscription = fields.Float(
		string="Frais d'inscription",
	)
	frais_formation_fonctionnaire = fields.Float(string='Frais de formation pour les fonctionnaires')
	frais_formation_nat = fields.Float(
		string="Frais de formation pour nationnaux",
	)
	frais_formation_inter = fields.Float(
		string="Frais de formation pour les internationaux",
	)

	classe_ids = fields.One2many(
		'gescoth.classe',
		'niveau_id',
		string='Classes',
	)

class GescothEvenement(models.Model):

	_name = 'gescoth.evenement'
	_inherit = ['mail.thread','mail.activity.mixin']
	_description = 'Evénement'

	name = fields.Char(string="Nom de l'évènement", required=True)
	date_debut = fields.Date(string="Date de début", required=True)
	date_fin = fields.Date(string="Date de fin", required=True)
	maxi_personne = fields.Integer(string="Maximum de participant")
	personnel_id = fields.Many2one(
		'gescoth.personnel',
		string='Organisateur',
	)
	nombre_limite = fields.Boolean(string="Le nombre de personnes est limité")
	nombre_peronne = fields.Integer(string="nombre de personne")
	participant_ids = fields.One2many('gescoth.enevement.participant', 'evement_id',
	string="Liste des participants")
	note = fields.Html('Note')

class GescothEnevementParticipant(models.Model):

	_name = 'gescoth.enevement.participant'
	_description = 'Participant'
	_rec_name = "eleve_id"

	eleve_id = fields.Many2one(
		'gescoth.eleve',
		string='Etudiant',
		required=True,
	)
	date_inscription = fields.Date(string="Date d'inscription",)
	evement_id = fields.Many2one(
		'gescoth.evenement',
		string='Evénement',
	)

class GescothHeureSuplementaire(models.Model):
    
	_name = 'gescoth.heure.suplementaire'
	_description = 'Heure suplémentaire'

	professeur_id = fields.Many2one(
		'gescoth.personnel',
		string='Enseignant',
		)
	annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année Académique',
    	default=lambda self: self.env['gescoth.anneescolaire'].browse(int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))
	)
	date_heure_sup = fields.Date(string="Date")
	nombre_heure = fields.Float(string="Nombre d'heure", default=2)
	moi_paie = fields.Selection([
		('0', 'Janvier'),
		('1', 'Février'),
		('2', 'Mars'),
		('3', 'Avril'),
		('4', 'Mai'),
		('5', 'Juin'),
		('6', 'Juillet'),
		('7', 'Août'),
		('8', 'Septembre'),
		('9', 'Octobre'),
		('10', 'Novembre'),
		('11', 'Décembre'),
	], string="Mois de paie")
	
	classe_id = fields.Many2one(
		'gescoth.classe',
		string='Classe',
		)
