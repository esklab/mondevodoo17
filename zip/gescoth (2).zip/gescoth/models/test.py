salaireBrut = categories.BASIC
cnss = salaireBrut * 4 / 100
semibrut = salaireBrut - cnss
abattement = semibrut * 28 / 100
revenu_semi_net = semibrut - abattement
allocation = 10000 * employee.children
revenu_net = revenu_semi_net - allocation
baseirpp = revenu_net

tranche1 = baseirpp  < 75000 >= 0
tranche2 = baseirpp < 333333.333 and baseirpp >= 75000
tranche3 = baseirpp < 500000 and baseirpp >= 333333.333
tranche4 = baseirpp  <  833333.333 and baseirpp >=  500000
tranche5 = baseirpp < 1250000 and baseirpp >=  833333.333
tranche6 = baseirpp >= 1250000


tranche1_irpp = (75000 - 0)*.5/100
tranche2_irpp = (333333.333 - 75000)*7/100
tranche3_irpp = (500000 - 333333.333)*15/100
tranche4_irpp = (833333.333 - 500000)*25/100
tranche5_irpp = (1250000 - 833333.333)*30/100
tranche6_irpp = (baseirpp)*35/100

if tranche1:
	irpp = baseirpp * .5 /100
if tranche2 :
	irpp = tranche1_irpp + (baseirpp - 75000) * 7/100
if tranche3 :
	irpp = tranche1_irpp + tranche2_irpp + (baseirpp - 333333.333) * 15/100
if tranche4 :
	irpp = tranche1_irpp + tranche2_irpp + tranche3_irpp +  (baseirpp - 500000) * 25/100
if tranche5 :
	irpp = tranche1_irpp + tranche2_irpp + tranche3_irpp + tranche4_irpp +  (baseirpp - 833333.333) * 30/100
if tranche6 :
	irpp = tranche1_irpp + tranche2_irpp + tranche3_irpp + tranche4_irpp + tranche5_irpp +  (baseirpp - 1250000) * 35/100

irpp = ((irpp / 10)) * 10

if irpp < 250:
	irpp = 250

result = irpp