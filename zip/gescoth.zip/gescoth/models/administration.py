# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

#classe pour ger les professeur
class GescothProfesseur(models.Model):
	_name = 'gescoth.personnel'
	_inherit = ['mail.thread','mail.activity.mixin']
	_description = 'Gestion de personnel'

	name = fields.Char(string="Nom et prénoms", required=True, track_visibility='onchange')
	matricule = fields.Char(string="Matricule", track_visibility='onchange')
	photo = fields.Binary(string="Photo de l'étudiant")
	date_naissance = fields.Date(string="Date de naissance",track_visibility='onchange')
	lieu_naissance = fields.Char(string="Lieu de naissance", track_visibility='onchange')
	sexe = fields.Selection([('masculin','Masculin'),('feminin','Féminin')], string="Sexe")
	nationalite = fields.Many2one('res.country', string="Nationalité")
	telephone = fields.Char(string="Téléphone", track_visibility='onchange')
	email =  fields.Char(string="E-mail")
	adresse= fields.Text(string="Adresse complète")
	numero_carte = fields.Char(string="N° pièce d’identité ")
	salaire_base = fields.Float(string="Salaire de base")
	taux_horaire = fields.Float(string="Taux horaire pour les heures supplémentaires")
	date_service = fields.Date(
		string='Date de prise de service'
		)
	post_id = fields.Many2one(
        'gescoth.poste',
        string='Poste occupé', required=True
    )
	est_professeur = fields.Boolean(strintg="Est un enseignant")
	statut = fields.Selection([('volontaire','Volontaire'),('permanent','Permanent'),('partiel','Partiel')], string='Statut')
	matieres = fields.Many2many('unite.enseignement', string="Unités d'enseignement")

	heure_sup_ids = fields.One2many('gescoth.heure.suplementaire', 'professeur_id',string="Heures supplémentaire")
	user_id = fields.Many2one(
		'res.users',
		string='Utilisateur relié',
	)
	autorise_saisie_note = fields.Boolean(
        string='Autorisé à saisir les notes',
    )
	active = fields.Boolean(string="Active", default=True)

class GescothPost(models.Model):
    _name = 'gescoth.poste'
    _description = 'Description'

    name = fields.Char(
    	string='',
    )


class ResCompany(models.Model):

	_inherit = 'res.company'

	nom_anglais = fields.Char(string='Nom en anglais')