from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError


class CritersValidation(models.Model):

    _name = 'criters.validation'
    _description = 'Critères de validation'
    _rec_name = 'validation'

    note_inf = fields.Float(string='Inf')
    note_sup = fields.Float(string='Sup')
    validation = fields.Selection([
        ('EC', 'Echec'),
        ('CANT','capitalisé non transférable'),
        ('CAR','capitalisation au rattrapage'),
        ('CA', 'Validé'),
    ])

    def _get_validation(self, note):
        for rec in self:
            validation = 'EC'
            if note >= rec.note_inf and note < rec.note_sup:
                validation = rec.validation
            return validation


class ExamenAnonymat(models.Model):

    _name = 'examen.anonymat'
    _description = 'Anonymat'
    _rec_name = 'eleve_id'

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Elève', required=True
    )
    annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année Académique',
        required=True,
		default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
	)
    examen = fields.Selection([
        ('cc', 'Controle continue (CC)'),
        ('tp', 'Travaux partiques (TP)'),
        ('tpe', 'Travaux partique individuel (TPE)'),
        ('sn', 'Session normal'),
        ('rt', 'Rattrapage')
    ])
    examen_id = fields.Many2one(
		'gescoth.examen.program',
		string='Examen',
	)

    code_anonymat = fields.Char(string='Anonymat', required=True)
    note_sur_20 = fields.Float(string='Note/20')
    note_sur_100 = fields.Float(string='Note/100')

    @api.onchange('note_sur_20')    
    def calcul_moyenne_sur100(self):
        for rec in self:
            rec.note_sur_100 = rec.note_sur_20 * 5

    



class UniteCredit(models.Model):

    _name = 'unite.credit'
    _description = 'Crédit'
    _rec_name = 'unite_id'

    unite_id = fields.Many2one(
        'unite.enseignement',
        string='Unite d\'enseigement', required=True
    )
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        )
    saison = fields.Selection([
        ('S1', 'Premiere semestre'),
        ('S2','Second semestre'),
    ])
    unite_libre = fields.Boolean(string="UE libre")
    credit = fields.Integer(string='Crédit', default="1")
    est_facult = fields.Boolean(string="Est optionnel")
    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
    )
    module_id = fields.Many2one(
        'unite.module',
        string='Module',                
    )

    @api.onchange('eleve_id')
    def onchange_eleve_id(self):
        for rec in self:
            rec.classe_id = rec.eleve_id.classe.id
    

class MethodeCalculeMoyenne(models.Model):

    _name = 'methode.calcule.moyenne'
    _description = 'Méthode de calcul'
    
    name = fields.Char(string='Descripton')
    pourcentage_cc = fields.Float(string='Pourcentage CC', default=20)
    pourcentage_tp = fields.Float(string='Pourcentage TP', default=20)
    pourcentage_tpe = fields.Float(string='Pourcentage TPE', default=60)
    pourcentage_examen = fields.Float(string='Pourcentage Session normale', default=60)


class UniteEnseignement(models.Model):

    _name = 'unite.enseignement'
    _description = 'Unité d\'enseignement(UE)'

    name = fields.Char(string='Nom', required=True)
    code = fields.Char(string='Code', required=True)
    description = fields.Text(string="Description")
    pourcentage_cc = fields.Float(string='Pourcentage CC')
    pourcentage_tp = fields.Float(string='Pourcentage TP')
    pourcentage_tpe = fields.Float(string='Pourcentage TPE')
    pourcentage_examen = fields.Float(string='Pourcentage session normale')

    type_unite = fields.Selection([
        ('theorie', 'Théorie'),
        ('pratique', 'Pratique'),
        ('stage','Stage'),
        ('soutenance','Soutenance d’un mémoire'),
    ])

    def moduifier_unite(self, context=None):
        return{
			'name':(self.name),
			'res_model':'unite.enseignement',
			'view_mode':'form',
            'context': self.env.context,
			'type':'ir.actions.act_window',
		}


class UniversiteNote(models.Model):

    _name = 'universite.note'
    _description = 'Note'
    _rec_name = 'eleve_id'

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
        )
    annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année Académique',
		default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
	)
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        )
    credit_id = fields.Many2one(
        'unite.credit',
        string='Unite d\'enseignement',
        )
    module_id = fields.Many2one(
        'unite.module',
        string='Module',
    )
    saison = fields.Selection([('S1','Semestre 1'),('S2','Semestre 2')], required=True)
    note_controle = fields.Float(string='(CC)Contrôl continu')
    travaux_pratique = fields.Float(string='(TP)Travaux partiques')
    travail_personnel = fields.Float(string='(TPE)Travaux partiques del\'étudiant')
    session_normale = fields.Float(string='(SN)Session pratique')
    note_ratrapage = fields.Float(string='(RT)Rattrapage')
    est_un_rattrapage = fields.Boolean(string='RT')
    moyenne = fields.Float(string='MGP', store=True, compute="_calcule_moyenne")
    moyenne_sur_20 = fields.Float(string='Moyenne sur 20', store=True, compute="_calcule_moyenne")

    moyenne_sur_cent = fields.Float(string='Moyenne/100', store=True, compute="_calcule_moyenne")
    appreciation = fields.Char(string='Appréciation', store=True, compute="_appreciation")
    grade = fields.Selection([
        ('a', 'A'),
        ('a+', 'A+'),
        ('a-', 'A-'),
        ('b', 'B'),
        ('b+', 'B+'),
        ('b-', 'B-'),
        ('c', 'C'),
        ('c+', 'C+'),
        ('c-', 'C-'),
        ('d', 'D'),
        ('e', 'E'),
        ('f', 'F'),
    ])

    moyenne_module = fields.Float(string='Moyenne de module', compute="calcul_moyenne_module")

    state = fields.Selection([
        ('non_valide', 'Non validé'),
        ('valide','Validé')
    ], default='non_valide')

    def annuler_validation(self):
        for rec in self:
            rec.state = "non_valide"

    def get_validation(self):
        for rec in self:
            validation_id = self.env['unite.validation'].search([('note_id','=', rec.id)], limit=1)
            return validation_id

    def calcul_moyenne_module(self):
        for rec in self:
            notes = self.env['universite.note'].search([
                ('classe_id','=', rec.classe_id.id),
                ('eleve_id','=', rec.eleve_id.id),
                ('annee_scolaire_id','=', rec.annee_scolaire_id.id),
                ('saison','=', rec.saison),
                ('module_id','=', rec.module_id.id),
            ])
            total = []
            total_credit = 0
            for note in notes:
                total_credit += note.credit_id.credit
                total.append(note.moyenne_sur_20)
            moyenne = (sum(total) / total_credit)
            rec.moyenne_module = moyenne
            note.moyenne_module = moyenne

    def _get_pourcentage(self):
        for rec in self:

            return {
                'pourcentage_cc':(float(rec.credit_id.unite_id.pourcentage_cc) / 100),
                'pourcentage_tp':(float(rec.credit_id.unite_id.pourcentage_tp) / 100),
                'pourcentage_tpe':(float(rec.credit_id.unite_id.pourcentage_tpe) / 100),
                'pourcentage_examen':(float(rec.credit_id.unite_id.pourcentage_examen) / 100),
            }

    def get_grade(self, note):
        grade = 'f'
        moyenne_sur_4 = 0
        if note >= 0 and note < 6:
            grade = 'f'
            moyenne_sur_4 = 0
        elif note >= 6 and note < 8:
            grade = 'e'
            moyenne_sur_4 = 1
        elif note >= 8 and note < 9:
            grade = 'd'
            moyenne_sur_4 = 1.3
        elif note >= 9 and note < 10:
            grade = 'c-'
            moyenne_sur_4 = 1.7
        elif note >= 10 and note < 11:
            grade = 'c'
            moyenne_sur_4 = 2
        elif note >= 11 and note < 12:
            grade = 'c+'
            moyenne_sur_4 = 2.3
        elif note >= 12 and note < 13:
            grade = 'b-'
            moyenne_sur_4 = 2.7
        elif note >= 13 and note < 14:
            grade = 'b'
            moyenne_sur_4 = 3
        elif note >= 14 and note < 16:
            grade = 'b+'
            moyenne_sur_4 = 3.3
        elif note >= 16 and note < 18:
            grade = 'a'
            moyenne_sur_4 = 3.7
        elif note >= 18:
            grade = 'a+'
            moyenne_sur_4 = 4

        return {
            'grade': grade,
            'moyenne_sur_4':moyenne_sur_4
        }

    def valider_note(self):
        for rec in self:
            criteres = self.env['criters.validation'].search([])
            validation = 'echec'
            credit = rec.credit_id.credit
            
            for critere in criteres:
                if rec.moyenne_sur_20 >= critere.note_inf and rec.moyenne_sur_20 < critere.note_sup:
                    validation = critere.validation
                if rec.moyenne_sur_20 >= 20:
                    validation = "CA"
            
            if validation == 'EC':
                if rec.module_id:
                    if rec.moyenne_module >= rec.module_id.moyenne_admition and rec.moyenne_sur_20 >= rec.module_id.moyenne:
                        validation = "CA"
                        credit = credit
                    else:
                        credit = 0
                else:
                    credit = 0
            else:
                validation = "CA"
                credit = credit
            
            vals ={
                'note_id':rec.id,
                'eleve_id': rec.eleve_id.id,
                'classe_id': rec.classe_id.id,
                'credit_id': rec.credit_id.id,
                'saison':rec.saison,
                'annee_scolaire_id': rec.annee_scolaire_id.id,
                'annee_scolaire_validation_id' : rec.annee_scolaire_id.id,
                'unite_enseignement_id':rec.credit_id.unite_id.id,
                'moyenne': rec.moyenne_sur_20,
                'moyenne_sur_cent': rec.moyenne_sur_cent,
                'credit':credit,
                'point': rec.moyenne,
                'total':(credit * rec.moyenne),
                'validation': validation,
                'appreciation': rec.appreciation,
                'grade':rec.grade,
                'state':rec.state,
            }

            exist_validation = self.env['unite.validation'].search([
                ('eleve_id','=', rec.eleve_id.id),
                ('annee_scolaire_id','=', rec.annee_scolaire_id.id),
                ('unite_enseignement_id','=', rec.credit_id.unite_id.id,),
            ])
            if not exist_validation:
                self.env['unite.validation'].create(vals)
            else:
                exist_validation.credit = credit
                exist_validation.validation = validation  
                exist_validation.point = rec.moyenne
                exist_validation.total = rec.moyenne * credit    
                exist_validation.appreciation = rec.appreciation  
                exist_validation.grade = rec.grade  
                exist_validation.state = rec.state  
            rec.state = 'valide'   

    @api.onchange('note_ratrapage')
    def _onchange_note_ratrapage(self):
        for rec in self:
            if rec.note_ratrapage > rec.session_normale:
                rec.est_un_rattrapage = True
            else:
                rec.est_un_rattrapage = False
    

    @api.depends('note_controle','travaux_pratique','travail_personnel','note_ratrapage','session_normale')    
    @api.onchange('note_controle','travaux_pratique','travail_personnel','note_ratrapage','session_normale')	    
    def _appreciation(self):
        appr = self.env['gescoth.appreciation'].search([])
        for rec in self:
            appreciation = ''
            for ap in appr:
                if rec.moyenne_sur_20 >= ap.inf and rec.moyenne_sur_20 < ap.sup:
                    appreciation = ap.name
                if rec.moyenne_sur_20 >= 20:
                    appreciation = 'Excellent'
            rec.appreciation = appreciation


    @api.depends('note_controle','travaux_pratique','travail_personnel','note_ratrapage','est_un_rattrapage', 'session_normale')    
    @api.onchange('note_controle','travaux_pratique','travail_personnel','note_ratrapage','est_un_rattrapage', 'session_normale')
    def _calcule_moyenne(self):
        for rec in self:
            pourcentage = rec._get_pourcentage()
            examen = rec.note_ratrapage if rec.est_un_rattrapage else rec.session_normale
            moyenne_sur_20 = (rec.note_controle * pourcentage.get('pourcentage_cc')) + (rec.travaux_pratique * pourcentage.get('pourcentage_tp')) + (rec.travail_personnel * pourcentage.get('pourcentage_tpe')) + (examen * pourcentage.get('pourcentage_examen'))
            rec.moyenne_sur_20 = moyenne_sur_20
            rec.moyenne_sur_cent = moyenne_sur_20 * 5
            rec.grade = rec.get_grade(moyenne_sur_20)['grade']
            rec.moyenne = rec.get_grade(moyenne_sur_20)['moyenne_sur_4']
            

    @api.onchange('note_controle','travaux_pratique','travail_personnel','note_ratrapage','est_un_rattrapage', 'session_normale')
    def _calcul_moyenne_module(self):
        for rec in self:
            all_notes = self.env['universite.note'].search([
                ('classe_id','=', rec.classe_id.id),
                ('annee_scolaire_id','=', rec.annee_scolaire_id.id),
                ('saison','=', rec.saison)                
            ])
            # raise UserError(_(len(all_notes)))
            for note in all_notes:
                note.calcul_moyenne_module()

    

    
class UniteModule(models.Model):

    _name = 'unite.module'
    _description = 'Module'
    name = fields.Char(string='Nom')
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        )
    moyenne_admition = fields.Float(string='Moy min UE pour compensation', default=10)
    moyenne = fields.Float(string='Moy requise pour le module')

class ModuleCritere(models.Model):

    _name = 'module.critere'
    _description = 'Critère de validation'
    _rec_name = 'module_id'

    note_inf = fields.Integer(string='Inférieur')
    note_superieur = fields.Float(string='Supérieur')
    module_id = fields.Many2one(
        'unite.module',
        string='Module',
    )


class UniteValidation(models.Model):

    _name = 'unite.validation'
    _description = 'Validation'
    _rec_name = 'eleve_id'

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
        )
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        )
    annee_scolaire_validation_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année Académique',
	)
    annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année Académique',
		default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
	)

    credit_id = fields.Many2one(
        'unite.credit',
        string='Unite d\'enseignement',
        )

    saison = fields.Selection([('S1','1er semestre'),('S2','Second semestre')], required=True)

    unite_enseignement_id = fields.Many2one(
        'unite.enseignement',
        string='Unite Enseignement',
        )
    moyenne = fields.Float(string='Moyenne')
    note_id = fields.Many2one(
        'universite.note',
        string='Note',
        )

    credit = fields.Float(string='Crédits')
    point = fields.Float(string='Point')
    total = fields.Float(string='Total')
    moyenne_sur_20 = fields.Float(string='Moyenne sur 20')
    moyenne_sur_cent = fields.Float(string='Moyenne sur 100')
    appreciation = fields.Char(string='Appreciation')
    grade = fields.Selection([
        ('a', 'A'),
        ('a+', 'A+'),
        ('a-', 'A-'),
        ('b', 'B'),
        ('b+', 'B+'),
        ('b-', 'B-'),
        ('c', 'C'),
        ('c+', 'C+'),
        ('c-', 'C-'),
        ('d', 'D'),
        ('e', 'E'),
        ('f', 'F'),
    ])

    validation = fields.Selection([
        ('EC', 'Echec'),
        ('CANT','capitalisé non transférable'),
        ('CAR','capitalisation au rattrapage'),
        ('CA', 'Validé'),
    ])
    state = fields.Selection([
        ('non_valide', 'Non validé'),
        ('valide','Validé')
    ], default='non_valide')

    decision = fields.Selection([
        ('AD', 'Admin'),
        ('EC', 'Echoué')
    ])

class GescothUniteResultat(models.Model):

    _name = 'gescoth.unite.resultat'
    _description = 'Resultat'
    _rec_name = 'eleve_id'

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
        )
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        )
    
    moyenne = fields.Float(string='MGP')
    moyenne_sur_100 = fields.Float(string='Moyenne/100')
    moyenne_sur_20 = fields.Float(string='Moyenne/20')
    credit = fields.Float(string='Crédit')
    pourcentage_credit = fields.Float(string='%Crédit')
    decision = fields.Selection([
        ('AD', 'Admin'),
        ('EC', 'Echec'),
    ])

    state = fields.Selection([
		('0', 'Non validé'),
		('1', 'Validé'),
	], default="0")

    annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		string='Année Académique',
		default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
	)
