# -*- coding: utf-8 -*-

from . import eleve
from . import ecole
from . import examen
from . import finance
from . import settings
# from . import cours
from . import administration
from . import actualite
from . import inscription

from . import universite