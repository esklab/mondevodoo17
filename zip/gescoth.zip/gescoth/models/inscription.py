# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class GescothEtudiantInscription(models.Model):

    _name = 'gescoth.eleve.inscription'
    _description = 'Inscription'
    _rec_name="annee_scolaire_id"

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année académique',
        required=True
        )
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        required=True,
    )

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
        required=True,
    )
    sexe = fields.Selection([('masculin','Masculin'),('feminin','Féminin')], string="Sexe", default='')
    montant_a_payer = fields.Float(string='Montant à payer', compute="_calcul_montant_a_payer")
    date_inscription = fields.Date(string="Date d'inscription")
    active = fields.Boolean(string="Active", default=True)

    def get_resultat(self):
        for rec in self:
            resultat = self.env['gescoth.unite.resultat'].search([
                ('eleve_id','=', rec.eleve_id.id),
                ('annee_scolaire_id','=', rec.annee_scolaire_id.id)
            ],limit=1
            )
            return resultat.decision

    def activer_inscription(self, state):
        for rec in self:
            rec.active = state

    def _calcul_montant_a_payer(self):
        for rec in self:
            paiements = self.env['gescoth.paiement.eleve'].search([('eleve_id','=',rec.id),('annee_scolaire_id','=', int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')))])
            current_country_id = self.env.user.company_id.country_id.id
            if current_country_id == rec.eleve_id.nationalite.id:
                total_paye = 0
                for p in paiements:
                    total_paye += p.montant
                if rec.eleve_id.est_fonctionnaire:
                    rec.montant_a_payer = rec.eleve_id.niveau_id.frais_formation_nat - total_paye
                else:
                    rec.montant_a_payer = rec.eleve_id.niveau_id.frais_formation_fonctionnaire - total_paye

            else:
                total_paye = 0
                for p in paiements:
                    total_paye += p.montant				
                rec.montant_a_payer = rec.eleve_id.niveau_id.frais_formation_inter - total_paye
