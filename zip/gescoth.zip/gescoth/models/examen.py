# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from .. functions.myFunctions import *
from datetime import datetime
import secrets
import random
import string


# classe pour gérer les les coeficients
class GescothCoeficient(models.Model):
	_name = 'gescoth.coeficient'
	_description = 'Gestion des coeficient'
	_rec_name = 'matiere'

	name = fields.Many2one('gescoth.classe', string="Classe")
	matiere = fields.Many2one('gescoth.matiere', string="Matière", required=True)
	est_facultative = fields.Boolean(string="La matière est facultative")
	coef = fields.Float(string="Coeficient", default=1)
	professeur_id = fields.Many2one('gescoth.personnel','Enseignant')
	

class GesocthNote(models.Model):
	_name = 'gescoth.note'
	_description = 'Gestion des notes'
	_rec_name = 'eleve_id'
	_sql_constraints = [
		('saison_unique_note', 'UNIQUE (eleve_id, classe_id, coeficient_id, saison)', 'Cette note existe déjà !')
	]

	eleve_id = fields.Many2one('gescoth.eleve', string="Etudiant", required=True)
	classe_id = fields.Many2one('gescoth.classe', string="Classe", required=True)  
	sexe = fields.Char(string="Sexe", store=True, compute="compute_sexe")
	coeficient_id = fields.Many2one('gescoth.coeficient', string="Matière", required=True)
	saison = fields.Selection([('S1','Semestre 1'),('S2','Semestre 2'),('s3','Semestre 3')], required=True)
	note_compo = fields.Float(string="Note de composition", store=True, group_operator='avg')
	moy_classe = fields.Float(string="Moyenne de classe", store=True, group_operator='avg')
	moyenne = fields.Float(string="Moyenne", default=0, store=True, compute="_onchange_note_compo", group_operator='avg')
	rang = fields.Char(string="Rang", compute="CalculerRang",)
	annee_scolaire = fields.Many2one('gescoth.anneescolaire', required=True, string="Année Académique",)
	professeur_id = fields.Many2one('gescoth.personnel', "Enseignant")
	appreciation = fields.Char(string='Appréciation', compute='Appreciation')
	state = fields.Selection([
		('0', 'Non validé'),
		('1', 'Validé'),
	], default="0", readonly=True)
    
	
	@api.depends('eleve_id')
	def compute_sexe(self):
		for rec in self:
			rec.sexe = rec.eleve_id.sexe
	
	# @api.onchange('note_compo','moy_classe')
	def CalculerRang(self):
		for rec in self:
			data = list()
			notes = self.env['gescoth.note'].search([
				('classe_id','=', rec.classe_id.id),
				('saison','=', rec.saison),
				('coeficient_id','=', rec.coeficient_id.id),
			])
			for note in notes:
				data.append(note.moyenne)
			
			rec.rang = Rang(rec.moyenne, rec.eleve_id.sexe, data)

	    

	@api.onchange('moy_classe','note_compo')	    
	def Appreciation(self):
		appr = self.env['gescoth.appreciation'].search([])
		for rec in self:
			for ap in appr:
				if rec.moyenne >= ap.inf and rec.moyenne < ap.sup:
					rec.appreciation = ap.name
				if rec.moyenne >= 20:
					rec.appreciation = 'Excellent'

	@api.constrains('moy_classe','note_compo')
	def check_notes(self):
		for rec in self:
			if rec.moy_classe < 0 or rec.moy_classe > 20:
				raise ValidationError(_('La moyenne de classe doit être entre 0 et 20. Vous avez taper : ' + str(rec.moy_classe)))
			if rec.note_compo < 0 or rec.note_compo> 20:
				raise ValidationError(_('La moyenne de classe doit être entre 0 et 20. Vous avez taper : ' + str(rec.note_compo)))

	@api.onchange('note_compo','moy_classe')
	@api.depends('note_compo','moy_classe')
	def _onchange_note_compo(self):
		for rec in self:
			if rec.coeficient_id.est_facultative:
				res = (rec.note_compo + rec.moy_classe)/2
				if res > 10:
					rec.moyenne = res-10
				else:
					rec.moyenne = 0
			else:
				rec.moyenne = (rec.note_compo + rec.moy_classe)/2
	
	def unlink(self):		
		for rec in self:
			if rec.state == '1':
				raise ValidationError(_('Vous ne pouvez pas supprimer les notes validées'))
			return super(GesocthNote, self).unlink()




class GescothAppreciation(models.Model):
	_name = 'gescoth.appreciation'
	_description = 'Gestion des appications'

	name= fields.Char(string="Appréciation")
	inf = fields.Float(string='Inférieur')
	sup = fields.Float(string='Supérieur')

class GescothDecision(models.Model):
	_name = 'gescoth.decision'
	_description = 'Décision'

	name= fields.Char(string="Décision")
	inf = fields.Float(string='Inférieur')
	sup = fields.Float(string='Supérieur')

class GescothResultatExamen(models.Model):
    _name = 'gescoth.examen.resultat'
    _description = "Resultat de l'exament"
    _rec_name = 'eleve_id'

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Etudiant',
        required=True,
    )
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        required=True,
    )

    saison = fields.Selection([
    	('S1','Semestre 1'),
    	('S2','Semestre 2'),
    ], 
    	required=True
    )

    annee_scolaire = fields.Many2one(
    	'gescoth.anneescolaire', 
    	required=True, 
    	string="Année Académique",
    )
    moyenne = fields.Float(
        string='Moyenne',
    )
    rang = fields.Char(
        string='Rang',
    )
    result = fields.Selection(string='Resultat', selection=[
		('0', 'Admis'),
		('1', 'Ajourné'),
	])

    state = fields.Selection([
		('0', 'Non validé'),
		('1', 'Validé'),
	], default="0")



class GescothProgramExamen(models.Model):
	_name = 'gescoth.examen.program'
	_description = "Examen et anonymat"

	name = fields.Char(
		string='Description',
		required=True
	)
	date_debut = fields.Date(
		string='Date de début', required=True
	)

	date_fin = fields.Date(
		string='Date de fin',
		required=True
	)
	annee_scolaire = fields.Many2one(
		'gescoth.anneescolaire', 
		required=True, 
		string="Année Académique",
		default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
	)

	classe_id = fields.Many2one(
		'gescoth.classe',
		string='Classe',
		required=True
	)
	unite_id = fields.Many2one(
		'unite.credit',
		string='Epreuve', required=True
	)
	examen_anonyme = fields.Boolean(string="Examen anonymé", default=True)
	saison = fields.Selection([('S1','Semestre 1'),('S2','Semestre 2')], required=True)

	type_examen = fields.Selection(string='Type d\'examen', selection=[
		('cc', 'Controle continue (CC)'),
		('tp', 'Travaux partiques (TP)'),
		('tpe', 'Travaux partique individuel (TPE)'),
		('sn', 'Session normal'),
		('rt', 'Rattrapage')
	], required=True)

	organisateur = fields.Many2one(
		'gescoth.personnel', 
		required=True, 
		string="Organisateur",
	)
	line_ids = fields.One2many(
		'gescoth.program.line',
		'program_id',
		string='Programmes',
	)
	anonymat_ids = fields.One2many('examen.anonymat', 'examen_id')
	state = fields.Selection([
		('new', 'Nouveau'),
		('confirm','Examen confirmé'),
		('anonymat','Anonymat généré'),
		('cancel','Annulé'),
		('valide','Notes validées'),
	], default='new')

	company_id = fields.Many2one(
        'res.company',
        string='Société',
        copy=True, store=True, index=True, 
        ondelete='restrict',
        default=lambda self: self.env['res.company']._company_default_get('gescoth').id
    )

	entete = fields.Binary(string="Entete", default=lambda self: self.env['ir.config_parameter'].sudo().get_param('gescoth.entete'))

	def liste_des_anonymat(self):
		return{
			'name':('Saisie des notes'),
			'domain':[('examen_id','=', self.id)],
			'res_model':'examen.anonymat',
			'view_id':False,
			'view_mode':'tree,form',
			'type':'ir.actions.act_window',
		}

	@api.onchange('classe_id')
	def onchange_classe_id(self):
		return {'domain':{'unite_id':[
            ('classe_id','=',self.classe_id.id),
        ]}}
	


	def valider_note(self):
		for rec in self:
			notes = self.env['universite.note'].search([
				('classe_id','=', rec.classe_id.id),
				('saison','=', rec.saison),
				('credit_id','=', rec.unite_id.id),
			])
			for note in notes:
				for anonymat in rec.anonymat_ids:
					if note.eleve_id.id == anonymat.eleve_id.id:
						if rec.type_examen == 'cc':
							note.note_controle = anonymat.note_sur_20

						if rec.type_examen == 'tp':
							note.travaux_pratique = anonymat.note_sur_20

						if rec.type_examen == 'tpe':
							note.travail_personnel = anonymat.note_sur_20
						
						if rec.type_examen == 'sn':
							note.session_normale = anonymat.note_sur_20

						if rec.type_examen == 'rt':
							note.note_ratrapage = anonymat.note_sur_20

			rec.state = 'valide'


	def confirmer_examen(self):
		for rec in self:
			rec.state = 'confirm'
	def generer_ananyma(self):
		for rec in self:
			rec._generer_ananyma()
			rec.state = 'anonymat'

	def annuler_examen(self):
		for rec in self:
			for anonymat in rec.anonymat_ids:
				anonymat.unlink()
			rec.state = 'cancel'
	# def modifier_note(self):
	# 	for rec in self:
	# 		rec.state = 'anonymat'

	def mettre_a_nouveau(self):
		for rec in self:
			rec.state = 'new'

	
	def _generer_ananyma(self):
		for rec in self:
			anonymat_codes = []
			# on a besoin de 5 caractère
			lettre = random.choice(string.ascii_letters).upper()
			for anonymat in rec.anonymat_ids:
				anonymat.unlink()

			note_ids = self.env['universite.note'].search([
				('classe_id','=', self.classe_id.id),
				('credit_id','=', self.unite_id.id),
        	])

			if len(note_ids) <= 0:
				raise UserError(_('Veuillez générer les notes d\'abord'))

			liste_des_etudiants =[]
			for note_id in note_ids:
				if self.type_examen != 'RT':
					if not  note_id.get_validation() or note_id.get_validation().validation == 'EC':
						liste_des_etudiants.append(note_id)
				else:
					if note_id.get_validation().validation == 'CA':
						liste_des_etudiants.append(note_id)

				
				for eleve in liste_des_etudiants:
					anonymat_code = secrets.token_hex(2).upper() + lettre #pour avoir les 5 caractères

					while anonymat_code in anonymat_codes:
						anonymat_code = secrets.token_hex(2).upper() + lettre #pour avoir les 5 caractères

					anonymat_codes.append(anonymat_code)

					vals ={
						'eleve_id':eleve.eleve_id.id,
						'annee_scolaire_id':rec.annee_scolaire.id,
						'examen':rec.type_examen,
						'code_anonymat': anonymat_code,
						'examen_id':rec.id,
					}
					# on crée l'anonyma s'il n'existe pas
					anonymat_existe = self.env['examen.anonymat'].search([
						('eleve_id','=', eleve.eleve_id.id),
						('annee_scolaire_id','=', rec.annee_scolaire.id),
						('examen','=', rec.type_examen),
						('examen_id','=', rec.id)
					])
					if not anonymat_existe:
						self.env['examen.anonymat'].create(vals)

class GescothProgramLine(models.Model):
    _name = 'gescoth.program.line'
    _rec_name="classe_id"

    date_examen = fields.Date(
        string='Date',
    )
    heure_debut = fields.Float(
        string='Heure de début',
    )
    heure_fin = fields.Float(
        string='Heure de fin',
    )

    professeur_id = fields.Many2one(
        'gescoth.personnel',
        string='Prof Surveillant',
    )
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
    )
    matiere_id = fields.Many2one(
        'gescoth.matiere',
        string='Matière',
    )
    program_id = fields.Many2one(
        'gescoth.examen.program',
        string='Programme',
    )
class GescothExamenDeliberation(models.Model):

	_name = 'gescoth.examen.deliberation'
	_description = 'Délibération'

	classe_id = fields.Many2one(
		'gescoth.classe',
		string='Classe',
		)
	

