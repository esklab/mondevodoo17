# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import * 
from odoo.exceptions import UserError, ValidationError

class GescothExamenDeliberation(models.TransientModel):
    _name = 'gescoth.examen.deliberation'
    _description = 'Délibération'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe',
        required=True,
    )
    moyenne = fields.Float(string='Moyenne(MGP) d\'admission')
    credit = fields.Float(string='Crédit d\'admision')
    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique prochaine',
        required=True,
        default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
    )

    annee_scolaire_en_cours_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique en cours',
        required=True,
    )

    classe_sup_id = fields.Many2one(
        'gescoth.classe',
        string='Classe supérieur',
        required=True,
    )
   
    result_ids = fields.Many2many('gescoth.unite.resultat', string="Resultat d'examen")

    @api.onchange('classe_id')
    def onchange_moyenne(self):
        for rec in self:
            rec.moyenne = rec.classe_id.moyenne_admission
            rec.credit = rec.classe_id.credit_admission
    

    @api.onchange('classe_id','type_saison', 'credit', 'moyenne','annee_scolaire_en_cours_id')
    def get_exame_result(self):
        for rec in self:            
            rec.result_ids = [(5,0,0)]
            rec.result_ids = self.env['gescoth.unite.resultat'].search([
                ('classe_id','=', self.classe_id.id),
                ('annee_scolaire_id','=', self.annee_scolaire_en_cours_id.id),           
            ]).ids
            
            for res in rec.result_ids:
                if rec.moyenne <= res.moyenne and rec.credit <= res.credit:
                    res.decision = 'AD'                    
                else:
                    res.decision = 'EC'
                

    def deliberer(self):
        for rec in self:
            notes = self.env['gescoth.note'].search([('classe_id','=', self.classe_id.id),('state','=','0')])
            if len(notes) > 0:
                raise ValidationError(_("Veuillez valider et clôturer d'abord toutes les notes de la classe " +  self.classe_id.name + ' !'))

            if rec.annee_scolaire_en_cours_id == rec.annee_scolaire_id:
                raise ValidationError(_("L'année en cours ne peut pas être égale à l'année prochaine ! \n Veuillez configurer l'Année Académique"))
            
            if rec.classe_id == rec.classe_sup_id:
                raise ValidationError(_("La classe en cours ne peut pas être égale à la classe supérieur!"))
            for result in rec.result_ids:
                if result.state == '0':
                    if result.moyenne >= rec.moyenne:
                        result.eleve_id.classe = rec.classe_sup_id.id
                    else:
                        result.eleve_id.classe = rec.classe_id.id
                    result.state = '1'
                else:
                    raise ValidationError(_('Résultat déjà validé'))
    
    def imprimer_resultat(self):
        data ={}
        resultats = []
        for line in self.result_ids:
            vals={
                'matricule':line.eleve_id.name,
                'eleve_id':line.eleve_id.nom_eleve,
                'moyenne':line.moyenne,
                'rang':line.rang,
                'result':['admin','Ajourné'][int(line.result)],
            }
            resultats.append(vals)
        data['resultats'] = resultats
        return self.env.ref('gescoth.impression_resultat_exament_report_view').report_action(self, data=data)