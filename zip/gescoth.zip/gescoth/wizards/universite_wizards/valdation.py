from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError

class ValidationUniteNote(models.TransientModel):

    _name = 'validation.unite.note'
    _description = 'Valider les notes'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe', required=True
    )
    saison = fields.Selection([('S1','1er semestre'),('S2','Second semestre')], required=True)
    
    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique',
        required=True,
        default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
    )

    def valider_note(self):
        notes  = self.env['universite.note'].search([
            ('classe_id','=', self.classe_id.id),
            ('saison','=', self.saison),
            ('annee_scolaire_id','=', self.annee_scolaire_id.id),
        ])
        for note in notes:
            note.valider_note()            