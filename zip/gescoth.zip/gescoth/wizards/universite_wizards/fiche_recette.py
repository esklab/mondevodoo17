from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError

class FicheRecette(models.TransientModel):

    _name = 'fiche.recette'
    _description = 'Fiche recette'

    compte_id = fields.Many2one(
        'compte.banque',
        string='Compte bancaire',
        default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.compte_id')),
    )
    numero = fields.Char(string='Numero de compte')

    eleve_id = fields.Many2one(
        'gescoth.eleve',
        string='Étudiant',
    )

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire',
        string='Année Académique',
        required=True,
        default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
    )
    montant = fields.Float(string='Montant')
    excecice = fields.Char(string='Excercice budgetaire')
    nature_recette = fields.Char(string='Nature de la récette')

    @api.onchange('compte_id')
    def onchange_compte_id(self):
        for rec in self:
            rec.numero = rec.compte_id.numero
    

    def imprimer_fiche_recette(self):
        data = {}
        vals = {
            'nom_compte': self.compte_id.name,
            'numero' : self.numero,
            'nom_eleve': self.eleve_id.nom_eleve,
            'annee_scolaire_id':self.annee_scolaire_id.name,
            'montant': self.montant,
            'matricule':self.eleve_id.name,
            'nationalite':self.eleve_id.nationalite.name,
            'excecice': self.excecice,
            'nature_recette':self.nature_recette,
            'classe': self.eleve_id.classe.name,
            'filiere':self.eleve_id.classe.filiere.name,
        }
        data['recette'] = vals
        return self.env.ref('gescoth.fiche_recette_report_view').report_action(self, data=data)
