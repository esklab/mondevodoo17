from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError


def get_grade(note):
        grade = 'f'
        moyenne_sur_4 = 0
        if note >= 0 and note < 6:
            grade = 'f'
            moyenne_sur_4 = 0
        elif note >= 6 and note < 8:
            grade = 'e'
            moyenne_sur_4 = 1
        elif note >= 8 and note < 9:
            grade = 'd'
            moyenne_sur_4 = 1.3
        elif note >= 9 and note < 10:
            grade = 'c-'
            moyenne_sur_4 = 1.7
        elif note >= 10 and note < 11:
            grade = 'c'
            moyenne_sur_4 = 2
        elif note >= 11 and note < 12:
            grade = 'c+'
            moyenne_sur_4 = 2.3
        elif note >= 12 and note < 13:
            grade = 'b-'
            moyenne_sur_4 = 2.7
        elif note >= 13 and note < 14:
            grade = 'b'
            moyenne_sur_4 = 3
        elif note >= 14 and note < 16:
            grade = 'b+'
            moyenne_sur_4 = 3.3
        elif note >= 16 and note < 18:
            grade = 'a'
            moyenne_sur_4 = 3.7
        elif note >= 18:
            grade = 'a+'
            moyenne_sur_4 = 4

        return {
            'grade': grade,
            'mgp':moyenne_sur_4
        }

class ProcesAnnuel(models.TransientModel):

    _name = 'proces.annuel'
    _description = 'Proces annuel'
    
    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe', required=True
    )

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire', 
        required=True, 
        string="Année Académique",
        default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
    )
    saison = fields.Selection([
        ('all','Annuel'),
        ('S1','Semestre 1'),
        ('S2','Semestre 2'),
        ], 
        required=True,
    )

    @api.onchange('classe_id')
    def onchange_classe_id(self):
        return {'domain':{'credit_id':[
            ('classe_id','=',self.classe_id.id),
        ]}}


    def imprimer_proces_verbal(self):
        data = {}
        liste_des_eleves = []
        header = []
        total_credit_normal = 0
        if self.saison == 'all':
            credit_ids = self.classe_id.credit_ids
        else:
            credit_ids = self.classe_id.credit_ids.search([('saison','=', self.saison)])

        for credit in credit_ids:
            total_credit_normal += credit.credit
            header.append({
                'nom':credit.unite_id.name,
                'code':credit.unite_id.code,
                'credit':credit.credit
            })
        
        # raise UserError(_(header))
        inscriptions = self.env['gescoth.eleve.inscription'].search([
            ('classe_id','=', self.classe_id.id),
            ('annee_scolaire_id','=', self.annee_scolaire_id.id),
        ])
        total_garcon = 0
        total_fille = 0
        garcon_admin = 0
        garcon_echoue = 0
        fille_admin = 0
        fille_echoue = 0

        for inscription in inscriptions:
            if inscription.sexe == 'masculin':
                total_garcon += 1
            else:
                total_fille += 1
            inscription_vals = {
                'nom_eleve': inscription.eleve_id.nom_eleve,
                'matricule': inscription.eleve_id.name,
                'decision': inscription.get_resultat()
            }    
            if inscription.get_resultat() == 'AD':
                if inscription.sexe == 'masculin':
                    garcon_admin += 1
                else:
                    fille_admin += 1
            else:
                if inscription.sexe == 'masculin':
                    garcon_echoue += 1
                else:
                    fille_echoue += 1

            if self.saison == 'all':
                notes = self.env['unite.validation'].search([
                    ('classe_id','=', self.classe_id.id),
                    ('eleve_id','=', inscription.eleve_id.id),
                    ('annee_scolaire_id','=', self.annee_scolaire_id.id),
                ])
            else:
                notes = self.env['unite.validation'].search([
                    ('classe_id','=', self.classe_id.id),
                    ('eleve_id','=', inscription.eleve_id.id),
                    ('annee_scolaire_id','=', self.annee_scolaire_id.id),
                    ('saison','=', self.saison)
                ])
            liste_notes = []
            total_credit = 0
            mgp = 0
            total_note = 0
            for note in notes:                  
                total_credit += note.credit
                total_note += note.moyenne_sur_20 *  note.credit
                note_vals = {
                    'nom_matiere': note.credit_id.unite_id.name,
                    'note_sur_100': round(note.moyenne_sur_cent,2),      
                }
                liste_notes.append(note_vals)

            inscription_vals['total_credit'] = total_credit

            inscription_vals['mgp'] = get_grade((total_note / total_credit))['mgp'] if total_credit > 0 else 0
            inscription_vals['liste_notes'] = liste_notes
            liste_des_eleves.append(inscription_vals)

   
        data['header'] = header
        data['liste_des_eleves'] = liste_des_eleves
        data['total_credit_normal'] = total_credit_normal
        data['niveau'] = self.classe_id.niveau_id.name.upper()
        data['total_garcon'] = total_garcon
        data['total_fille'] = total_fille
        data['garcon_admin'] = garcon_admin
        data['garcon_echoue'] = garcon_echoue
        data['fille_admin'] = fille_admin
        data['fille_echoue'] = fille_echoue

        return self.env.ref('gescoth.pv_annuel_report_view').report_action(self, data=data)
