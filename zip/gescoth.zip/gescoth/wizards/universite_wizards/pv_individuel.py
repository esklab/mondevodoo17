from odoo import _, api, fields, models, tools 
from odoo.exceptions import UserError, ValidationError

class ProcesVerbal(models.TransientModel):

    _name = 'proces.verbale'
    _description = 'Générer les notes'

    classe_id = fields.Many2one(
        'gescoth.classe',
        string='Classe', required=True
    )

    annee_scolaire_id = fields.Many2one(
        'gescoth.anneescolaire', 
        required=True, 
        string="Année Académique",
        default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
    )
    credit_id = fields.Many2one(
        'unite.credit',
        string='unite',
        required=True
    )

    saison = fields.Selection([
        ('S1','Semestre 1'),
        ('S2','Semestre 2'),
        ], 
        required=True,
    )
    def imprimer_proces_verbal(self):
        data = {}
        notes = self.env['universite.note'].search([
            ('credit_id','=', self.credit_id.id),
            ('classe_id','=', self.classe_id.id),
            ('annee_scolaire_id','=', self.annee_scolaire_id.id),
        ])
        liste_notes = []
        header = {
            'cc':self.credit_id.unite_id.pourcentage_cc != 0,
            'tp': self.credit_id.unite_id.pourcentage_tp != 0,
            'tpe': self.credit_id.unite_id.pourcentage_tpe != 0,
            'sn': self.credit_id.unite_id.pourcentage_examen != 0,
        }
        for note in notes:
            state = note.get_validation().validation
            vals = {
                'nom_eleve': note.eleve_id.nom_eleve,
                'matricule': note.eleve_id.name,
                'matiere':note.credit_id.unite_id.name,
                'cc':round(note.note_controle,2),
                'tp':round(note.travaux_pratique,2),
                'tpe':round(note.travail_personnel,2),
                'sn':round(note.session_normale,2),
                'rt':round(note.note_ratrapage,2),
                'est_rt':note.est_un_rattrapage,
                'moyenne_sur_20':round(note.moyenne_sur_20,2),
                'moyenne_sur_cent':round(note.moyenne_sur_cent,2),
                'dec':state,
                'grade':note.grade,
            }
            liste_notes.append(vals)
        data['liste_des_notes'] = liste_notes
        data['header'] = header
        return self.env.ref('gescoth.pv_individuel_report_view').report_action(self, data=data)