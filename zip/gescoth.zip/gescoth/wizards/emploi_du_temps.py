# -*- coding: utf-8 -*-
from odoo import models, fields, api, _ 
from odoo.exceptions import UserError, ValidationError

class GescothEmploiWizard(models.TransientModel):
    _name = 'gescoth.emploi.wizard'
    _description = 'Emploi du temps'

    professeur_id = fields.Many2one(
        'gescoth.personnel',
        string='Professeur',
        
        )
    annee_scolaire_id = fields.Many2one(
		'gescoth.anneescolaire',
		required=True,
		string="Année scolaire",
		default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
	)

    def imprimer_emploi_du_temps(self):
        data = {}
        list_emplois = []
        emplois_ids = self.env['gescoth.emploi.temps.line'].search([
            ('professeur_ids', 'in', self.professeur_id.id)
        ])

        for emplois_id in emplois_ids:
            if emplois_id.emploi_id.annee_scolaire_id.id == self.annee_scolaire_id.id:
                vals ={
                    'date':emplois_id.date,
                    'heure_debut':'%02d:%02d' % (int(emplois_id.heure_debut), emplois_id.heure_debut % 1 * 60),
                    'heure_fin':'%02d:%02d' % (int(emplois_id.heure_fin), emplois_id.heure_fin % 1 * 60),
                    'unite_id':emplois_id.unite_id.name,
                    'type_de_cours': emplois_id.type_de_cours,
                    'titre_du_cours':emplois_id.titre_du_cours,
                    'classe':emplois_id.emploi_id.classe_id.name,
                }
                list_emplois.append(vals)

        data['list_emplois'] = list_emplois    
        data['annee_scolaire'] =  self.annee_scolaire_id.name
        data['professeur'] = self.professeur_id.name[0],        
        return self.env.ref('gescoth.emploi_du_temps_report_view').report_action(self, data=data)
