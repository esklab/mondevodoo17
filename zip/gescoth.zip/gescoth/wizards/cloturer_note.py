# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import *
from odoo.exceptions import ValidationError

class GescothCloturerNote(models.TransientModel):

    _name = 'gescoth.cloturer.note'
    _description = 'Clôturer les notes'

    classe_ids = fields.Many2many('gescoth.classe', required=True)
    annee_scolaire = fields.Many2one('gescoth.anneescolaire',
    default=lambda self: int(self.env['ir.config_parameter'].sudo().get_param('gescoth.annee_scolaire_id')),
	required=True, string="Année Académique",)
    saison = fields.Selection([
        ('all', 'Tout'),
    	('S1','Semestre 1'),
    	('S2','Semestre 2'),
    ], 
    	required=True
    )
    note_ids = fields.Many2many('gescoth.note')
    
    @api.onchange('classe_ids','saison','annee_scolaire')
    def _get_notes(self):
        for rec in self:
            if self.saison == 'all':
                rec.note_ids = self.env['gescoth.note'].search([
                    ('classe_id','in',rec.classe_ids.ids),
                    ('annee_scolaire','=', rec.annee_scolaire.id),
                ])
            else:
                rec.note_ids = self.env['gescoth.note'].search([
                    ('classe_id','in',rec.classe_ids.ids),
                    ('annee_scolaire','=', rec.annee_scolaire.id),
                    ('saison','=',rec.saison),
                ])
    

    def cloturer_note(self):
        for rec in self:
            for note in rec.note_ids:
                note.state = '1'