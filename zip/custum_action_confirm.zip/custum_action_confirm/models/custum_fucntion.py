from odoo import models, api, fields, _
import logging
from odoo.exceptions import ValidationError

# Configurer le logger
_logger = logging.getLogger(__name__)

class CustomAdmission(models.Model):
    _inherit = 'oe.admission'

    inscription_confirmed = fields.Boolean(string="Inscription Confirmed", default=False)
    parent_created = fields.Boolean(string="Parent creer", default=False)

    def action_confirm_admission_create_parent(self):
        if not self.x_studio_nom_complet_du_pre:
            raise ValidationError("Le nom du parent est vide. Vous ne pouvez pas creer le parent d'eleve sans son nom.")
        _logger.info("parent: %s", self.partner_id.id)
        
        parent_vals = {
            'is_student':True,
            'is_parent_student': True,
            'parent_id':self.partner_id.id,
            'name': self.x_studio_nom_complet_du_pre,
            'country_nationality': self.x_studio_nationalite,
            'phone': self.x_studio_tlphonie_rsidentielle,
            'mobile': self.x_studio_numro_whatsapp_1,
            'email': self.x_studio_email,
            'student_emergency_phone': self.x_studio_contact_durgence_1,
            'team_id': False
            #'lang':,
            #'date_birth':,
            #'gender':,
            #'merital_status':,
            #'country_birth':,
            #'student_emergency_contact':,

        }
        self.env['res.partner'].create(parent_vals)
        _logger.info("Creating partner with values: %s", parent_vals)
        self.parent_created=True
        _logger.info("statut %s",self.parent_created)

    def action_confirm_admission_inscription(self):
        _logger.info(f"Searching for partner with name: {self.partner_id.name}")

        # Rechercher le template de commande
        template = self.env['sale.order.template'].search([('name', '=', 'FRAIS')], limit=1)
        
        # Vérifier et obtenir l'équipe d'admission
        admission_team = self.team_id
        _logger.info(f"Order created successfully with ID: {admission_team.id}.") 

        if not admission_team:
            raise ValueError("Aucune équipe d'admission valide n'a été trouvée.")

        # Création de la nouvelle inscription
        enrollment_vals = {
            'partner_id': self.partner_id.id,
            'sale_order_template_id': template.id,
            'date_order': fields.Datetime.now(),
            'admission_team_id': admission_team.id, 
            'team_id': 1,
            'is_enrol_order': True,
            'order_line': [[{'product_id': 16, 'product_template_id': 16, 'product_uom_qty': 1}]],
        }
        
        sale_order = self.env['sale.order'].create(enrollment_vals)
        _logger.info(f"Order created successfully with ID: {sale_order.id}.")
        self.inscription_confirmed = True
        _logger.info("statut %s",self.inscription_confirmed)

class ResPartner(models.Model):
    _inherit = 'res.partner'

    @api.model
    def create(self, vals):
        # Log all the values passed to the create method
        _logger.info(f"Creating Partner with values: {vals}")
        
        # Call the super method to actually create the record
        record = super(ResPartner, self).create(vals)
        
        # Optionally log the created record's ID
        _logger.info(f"Partner Created with ID: {record.id}")
        
        # Return the created record
        return record

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.model
    def create(self, vals):
        # Log all the values passed to the create method
        _logger.info(f"Creating Sale Order with values: {vals}")
        
        # Call the super method to actually create the record
        record = super(SaleOrder, self).create(vals)
        
        # Optionally log the created record's ID
        _logger.info(f"Sale Order Created with ID: {record.id}")
        
        # Return the created record
        return record