{
    'name': 'Custom function cisl',
    'version': '1.0',
    'description': 'Custom fucntion cisl',
    'summary': 'Custom fucntion cisl',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'de_school_admission'
    ],
    "data": [
        "views/oe_admission_views.xml"
    ],
    'auto_install': False,
    'application': True,
}