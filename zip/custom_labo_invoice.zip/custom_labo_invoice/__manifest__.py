{
    'name': 'Custom Request Facture',
    'version': '1.0',
    'description': 'Custom Request Facture',
    'summary': 'Custom Request Facture',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'acs_laboratory',
    ],
    "data": [],
    'auto_install': False,
    'application': True,
}