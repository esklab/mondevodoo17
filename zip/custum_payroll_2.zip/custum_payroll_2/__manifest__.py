{
    'name': 'Custum Payroll B',
    'version': '1.0',
    'description': 'Custum Payroll B',
    'summary': 'Custum Payroll B',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'hr_payroll',
    ],
    "data": [
        "security/ir.model.access.csv",
        "data/data.xml",
        "views/hr_contract_views.xml",
        "views/hr_salary_views.xml"
    ],
    'auto_install': False,
    'application': True,
}