## Module <hotel_management_odoo>

#### 15.01.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Hotel Management

#### 29.03.2024
#### Version 17.0.1.0.1
#### UPDATE
 - Add a validation for timezone in dashboard.

#### 27.06.2024
#### Version 17.0.1.0.2
#### UPDATE
 - Corrected the work flow of deleting and canceling records in room booking model

#### 04.07.2024
#### Version 17.0.1.1.3
#### UPDATE
 - Updated the workflow maintenance request and cleaning request model(removed a field from each)

#### 04.09.2024
#### Version 17.0.1.2.5
#### UPDATE
 - Updated the workflow in room booking line since a validation error doesnot allows booking after reserved days and 
also in room booking report since the checkin date and checkout date was not correct