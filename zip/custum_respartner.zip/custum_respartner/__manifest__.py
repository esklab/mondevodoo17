{
    'name': 'Custom Respartner',
    'version': '1.0',
    'description': 'Custom Respartner',
    'summary': 'Custom Respartner',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'contacts',
    ],
    "data": [
        "views/res_partner_views.xml"
    ],
    'auto_install': False,
    'application': True,
}