import requests
from odoo import models, fields, api
from odoo.exceptions import UserError

class ACSLaboratoryRequest(models.Model):
    _inherit = 'acs.laboratory.request'

    @api.model
    def send_request_to_api(self):
        # Préparer les données
        data = {
            "count": 1,
            "results": [
                {
                    "request_id": self.id,
                    "x_studio_code_demande": self.x_studio_code_demande,
                    "id": self.id,
                    "name": self.name,
                    "patient_id": self.patient_id.id,
                    "x_studio_nom_patient": self.patient_id.name,
                    "x_studio_code_patient": self.x_studio_code_patient,
                    "x_studio_date_naissance": self.x_studio_date_naissance,
                    "x_studio_sexe": self.x_studio_sexe,
                    "sample_ids": [
                        {
                            "id": sample.id,
                            "name": sample.name,
                            "test_ids": [
                                {
                                    "id": test.id,
                                    "name": test.name,
                                    "x_studio_valeur_automate": test.x_studio_valeur_automate,
                                    "x_studio_unit_automate": test.x_studio_unit_automate
                                } for test in sample.test_ids
                            ]
                        } for sample in self.sample_ids
                    ],
                    "user_id": self.user_id.id,
                    "x_studio_automate": self.x_studio_automate,
                    "date_requested": self.date_requested,
                    "date_analysis": self.date_analysis,
                }
            ]
        }

        # URL de l'API
        url = "https://biasa.steros.net/api/DemandeAnalyse/Synchronize"

        try:
            # Envoyer les données avec une requête POST
            response = requests.post(url, json=data)
            # Vérifier la réponse de l'API
            if response.status_code != 200:
                raise UserError(f"Erreur lors de l'envoi des données à l'API: {response.text}")
        except requests.exceptions.RequestException as e:
            raise UserError(f"Erreur de connexion à l'API : {str(e)}")
