{
    'name': 'Automate Api',
    'version': '2.0',
    'description': 'Automate Api',
    'summary': 'Automate Api',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': ['base','acs_laboratory',],
    "data": [
        "views/acs_laboratory_request_views.xml"
    ],
    'auto_install': False,
    'application': True,
}