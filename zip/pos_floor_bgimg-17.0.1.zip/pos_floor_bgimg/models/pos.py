# -*- coding: utf-8 -*-


# from odoo import fields, models,tools,api
# import logging



# class pos_config(models.Model):
#     _inherit = 'pos.config' 
    
#     background_image = fields.Binary("Image")

from odoo import fields, models,tools,api

    

class PosSession(models.Model):
    _inherit = 'pos.session'


    def _loader_params_restaurant_floor(self):
        result = super()._loader_params_restaurant_floor()
        result['search_params']['fields'].extend(['background_image'])
        return result