# -*- coding: utf-8 -*-
{
    'name': "POS Floor Background Image",
    'version': '1',
    'summary': """
        This module helps us to set background image on floor Screen.

        """,
    'author': 'WebVeer',
    'category': 'Point Of Sale',
    
    'website': '',

    'depends': ['pos_restaurant'],
    'data': [
            'views/pos.xml'
        ],
    'assets': {
        'point_of_sale.assets': [
            'pos_floor_bgimg/static/src/js/pos.js',
        ],
    },
    'images': ['static/description/floor_img.jpg'],
    'price': 19.00,
    'currency': 'EUR',
    'installable': True,
}
