odoo.define('pos_floor_bgimg.pos_floor_bgimg', function(require){
    const FloorScreen = require('pos_restaurant.FloorScreen');
    const Registries = require('point_of_sale.Registries');

    

    const FloorScreen2 = FloorScreen =>
        class extends FloorScreen {
            onPatched() {
            	if(this.activeFloor.background_image){
	            	this.floorMapRef.el.style.background = "url(/web/image?model=restaurant.floor&id="+this.activeFloor.id+"&field=background_image)";
            	}
            	else{
	            	this.floorMapRef.el.style.background = this.state.floorBackground;
	            }
                this.state.floorMapScrollTop = this.floorMapRef.el.getBoundingClientRect().top;
	        }
        };

    Registries.Component.extend(FloorScreen, FloorScreen2);

});
