{
    'name': 'Custom Facture Yual',
    'version': '1.0',
    'description': 'Custom Facture Yual',
    'summary': 'Custom Facture Yual',
    'author': 'maono',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
        'account',
    ],
    "data": [
        "views/account_move_views.xml",
    ],
    'auto_install': False,
    'application': True,
}